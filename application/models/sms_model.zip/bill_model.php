<?php if (! defined('BASEPATH')) exit('No direct script access allowed');

class Bill_model extends CI_Model {

	function __construct(){
		parent::__construct();
	}

	public static $table = "bills";
	public static $table2 = "suppliers";

    public function getAllsuppiler($where = [], $limit = false){
		if(!empty($where)) $this->db->where($where);
		if($limit != false) $this->db->limit($limit);
		$this->db->order_by('id','desc');
		$query = $this->db->get(self::$table2);
		return $query->num_rows() > 0 ? $query->result_array() : false;
	}
	public function get($where = []){
		$query = $this->db->get_where(self::$table, $where);
		return $query->num_rows() > 0 ? $query->row_array() : false;
	}
	public function get_sup($where = []){
		$query = $this->db->get_where(self::$table2, $where);
		return $query->num_rows() > 0 ? $query->row_array() : false;
	}

	public function getAll($where = [], $limit = false){
		if(!empty($where)) $this->db->where($where);
		if($limit != false) $this->db->limit($limit);
		$this->db->order_by('id','desc');
		$query = $this->db->get(self::$table);
		return $query->num_rows() > 0 ? $query->result_array() : false;
	}

	public function create($data)
	{
		$this->db->insert(self::$table, $data);
		$insert_id = $this->db->insert_id();
		return $insert_id;
	}

	public function validate_string($table,$column,$val,$id)
	{
		$this->db->where("id !=",$id);
		$this->db->where($column,$val);
		$query = $this->db->get($table);
		return $query->num_rows() > 0 ? true : false;
	}

	public function update($data, $id){
		if($this->db->update(self::$table, $data, ['id' => $id]))
			return true;
		else
			return false;
	}

	public function delete($id){
		return $this->db->delete(self::$table, ['id' => $id]);
	}
	
	public function multiCondition($table,$conditions,$result = 'all')
	{
		if($conditions)
		$this->db->where($conditions);
		$query = $this->db->get($table);
		if($result == 'all')
			return $query->result_array();
		else
			return $query->row_array();
	}
	public function countRows($table,$cond = array())
	{
		 $this->db->where($cond);
		return $this->db->count_all_results($table);
	}
	public function getField($tableName,$cond = array(),$field)
	{
		$this->db->where($cond);
		$query = $this->db->get($tableName);
		$record = $query->row_array();
		if (!empty($record)) {
			return $record[$field];
		}
		else
			return 'Not found';
		
	}
	public function getRow($tableName,$cond = array())
	{
		if($cond) $this->db->where($cond);
		$query = $this->db->get($tableName);
		return $query->row_array();
	}
	
		public function getRowM($tableName,$cond = array())
	{
		if($cond) $this->db->where($cond);
		$query = $this->db->get($tableName);
		return $query->result_array();
	}
	
	
	
	public function getTableData($tableName)
	{
		$query = $this->db->get($tableName);
		 return $query->result_array();
	}
	
	

}