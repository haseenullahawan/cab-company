<?php $locale_info = localeconv(); ?>
<script type="text/javascript">
    var supplier = '';
    var dataSupplier = "<?php print_r($suppliers); ?>";
    var delay = '';
</script>
<div class="col-md-12"><!--col-md-10 padding white right-p-->
    <div class="content">
        <?php $this->load->view('admin/common/breadcrumbs'); ?>
        <div class="row">
            <div class="col-md-12">
                <?php $this->load->view('admin/common/alert'); ?>
                <div class="module">
                    <?php echo $this->session->flashdata('message'); ?>
                    <div class="module-head">
                    </div>
                    <div class="module-body">
                        <?= form_open("admin/sales/add") ?>
                        <div class="row">
                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>Supplier* </label>
                                    <select class="form-control" name="supplier_id" id="supplier_id" required>

                                        <?php foreach ($suppliers as $key => $value): ?>
                                            <option
                                                value="<?php echo $value['id'] ?>"><?php echo $value['first_name'] ?></option>
                                        <?php endforeach ?>
                                    </select>
                                </div>

                            </div>
                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>Category*</label>

                                    <div class="input-group">
                                        <span class="input-group-addon"></span>
                                        <select name="category" id="category" required>
                                            <option value="New">New</option>
                                            <option value="Regular">Regular</option>
                                            <option value="Old">Old</option>
                                            <!--<option></option>-->
                                        </select>
                                        <!--<input id="phone-email" maxlength="100" type="text" class="form-control" required name="category" placeholder="category" value="<?= set_value('to_pay', $this->input->post('to_pay')) ?>">-->
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>Status*</label>
                                    <select class="form-control" name="status" required>
                                        <?php foreach (config_model::$status as $key => $status): ?>
                                            <option <?= set_value('status', $this->input->post('status')) == $status ? "selected" : "" ?>
                                                value="<?= $status ?>"><?= $status ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>

                        </div>

                        <div class="row">
                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>delay*</label>

                                    <div class="input-group">
                                        <span class="input-group-addon"></span>
                                        <input type="text" class="form-control" name="delay" id="delay">
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>VAT*</label>

                                    <div class="input-group">
                                        <span class="input-group-addon"></span>
                                        <input maxlength="50" type="text" class="form-control" required name="VAT"
                                               id="VAT">
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>Invoice number</label>
                                    <input type="text" class="form-control" name="invoice_number" id="invoice_number">
                                </div>
                            </div>
                            <!--<div class="col-xs-4">-->
                            <!--    <div class="form-group">-->
                            <!--        <label>Amount</label>-->
                            <!--        <input type="text" class="form-control" name="amount" id="amount">-->
                            <!--    </div>-->
                            <!--</div>-->
                        </div>
                        <div class="row">
                            <!--<div class="col-xs-4">-->
                            <!--    <div class="form-group">-->
                            <!--        <label>To pay*</label>-->
                            <!--        <div class="input-group">-->
                            <!--            <span class="input-group-addon"></span>-->
                            <!--            <input id="to_pay" maxlength="100" type="text" class="form-control" required name="to_pay">-->
                            <!--        </div>-->
                            <!--    </div>-->
                            <!--</div>-->


                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>Invoice date*</label>

                                    <div class="input-group">
                                        <span class="input-group-addon"></span>
                                        <input maxlength="50" type="date" class="form-control" required
                                               name="invoice_date" id="invoice_date" onchange="givedelayDate()">

                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>Delay date*</label>

                                    <div class="input-group">
                                        <span class="input-group-addon"></span>
                                        <input maxlength="50" type="date" class="form-control" required
                                               name="delay_date" id="delay_date" placeholder="Delay date">
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>Amount</label>
                                    <input type="number" class="form-control" name="amount" id="amount">
                                </div>
                            </div>
                        </div>
                        <div class="row">


                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>Fees*</label>

                                    <div class="input-group">
                                        <span class="input-group-addon"></span>
                                        <input id="fees" maxlength="50" type="number" class="form-control" required
                                               name="fees">
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>Penality</label>
                                    <input type="text" class="form-control" name="penality" id="penality">
                                </div>
                            </div>
                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>To pay*</label>

                                    <div class="input-group">
                                        <span class="input-group-addon"></span>
                                        <input id="to_pay" maxlength="100" type="number" class="form-control" required
                                               name="to_pay" onfocus="toPay()">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>Amount</label>
                                    <input type="text" class="form-control" name="amount_pay" id="amount_pay"
                                           onchange="payAmount()">
                                </div>
                            </div>
                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>Payment Method*</label>
                                    <select class="form-control" name="payment_method_id" id="pay_method" required>

                                    </select>
                                </div>
                            </div>
                            <!--<div class="col-xs-4">-->
                            <!--    <div class="form-group">-->
                            <!--        <label>Reference*</label>-->
                            <!--        <input type="text" class="form-control" name="reference" placeholder="reference" value="<?= set_value('reference', $this->input->post('reference')) ?>">-->
                            <!--    </div>-->
                            <!--</div>-->
                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>Date*</label>
                                    <input type="date" class="form-control" name="bill_date" placeholder="bill_date"
                                           value="<?= set_value('bill_date', $this->input->post('bill_date')) ?>">
                                </div>
                            </div>

                        </div>

                        <div class="row">
                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>Due Amount</label>
                                    <input type="text" class="form-control" name="due_amount" id="due_amount">
                                </div>
                            </div>
                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>Reference*</label>
                                    <input type="text" class="form-control" name="reference" placeholder="reference"
                                           value="<?= set_value('reference', $this->input->post('reference')) ?>">
                                </div>
                            </div>

                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>Recurrency*</label>
                                    <select name="reccurency" id="recc" onchange="visible()">
                                        <option value="no">No</option>
                                        <option value="yes">Yes</option>
                                        <option value="3">3 Month</option>
                                        <option value="6">6 Month</option>
                                        <option value="12">12 Month</option>
                                    </select>
                                </div>
                            </div>

                            <div class="col-xs-4" style="display: none" id="eachh">
                                <div class="form-group">
                                    <label>Each*</label>
                                    <input type="text" class="form-control"  name="eachh" placeholder="Each" value="0">
                                </div>
                            </div>

                            <div class="col-xs-4" style="display: none;" id="dayy">
                                <div class="form-group">
                                    <label>Day*</label>
                                    <input type="text" class="form-control"  name="dayy" placeholder="Day" value="0">
                                </div>
                            </div>


                        </div>
                        <hr>
                        <div class="text-right">
                            <button class="btn btn-default">Save</button>
                            <a href="<?= base_url("admin/sales") ?>" class="btn btn-default">Cancel</a>
                        </div>

                        <?php echo form_close(); ?>
                    </div>
                </div>
            </div>
        </div>
        <!--/.module-->
    </div>
    <!--/.content-->
</div>

<script type="text/javascript">

    supplierData();



    function  visible(){
        var recur = $("#recc").val();
        recur = recur.trim();
        if(recur != "no"){
            $("#eachh").show();
            $("#dayy").show();
        }else{

            $("#eachh").hide();
            $("#dayy").hide();
        }


    }

    function supplierData() {

        supplier = $('#supplier_id').val();
        //alert(supplier);

        //alert(dataSupplier);
        var arrayFromPHP = <?php echo json_encode($suppliers); ?>;
        var pm = <?php echo json_encode($payment_methods); ?>;
        var m = 1;
        var p_method = '';
        $.each(arrayFromPHP, function (i, elem) {
            // do your stuff

            if (arrayFromPHP[i].id == supplier) {
                delay = arrayFromPHP[i].delay;
                $("#delay").val(arrayFromPHP[i].delay);
                $("#VAT").val(arrayFromPHP[i].VAT);
                $("#to_pay").val(arrayFromPHP[i].to_pay);

                if (m == 1) {
                    for (var j = pm.length - 1; j >= 0; j--) {
                        if (arrayFromPHP[i].payment_method_id == pm[j].id) {
                            selected = "selected";
                        }
                        else {
                            selected = "";
                        }
                        p_method += '<option value="' + pm[j].id + '" ' + selected + '>' + pm[j].name + '</option>';
                    }
                    $("#pay_method").prepend(p_method);

                }
                m++;
                $("#category").prepend('<option value="' + arrayFromPHP[i].category + '" selected>' + arrayFromPHP[i].category + '</option>');
                //alert(arrayFromPHP[i].delay);
            }

        });
        //$("#VAT").text(delay);

    }

    $(document).ready(function () {
        $("#supplier_id").on("change", function () {
            sup = $(this).val();
            window.location.href = window.location.origin + "/sales/add/" + sup;
        });
    });

    function toPay() {
        var amount = parseInt($("#amount").val());
        var fees = parseInt($("#fees").val());
        var penality = parseInt($("#penality").val());

        var pay = amount + fees + penality;
        //alert(pay);
        $("#to_pay").val(pay);
    }

    function payAmount() {
        var amountpay = parseInt($("#amount_pay").val());
        var toPay = parseInt($("#to_pay").val());
        var pay = toPay - amountpay;
            alert(pay);
            $("#due_amount").val(pay);
    }

    function givedelayDate() {

        var date = new Date($("#invoice_date").val()),
            days = parseInt($("#delay").val(), 10);

        if (!isNaN(date.getTime())) {
            date.setDate(date.getDate() + days);
// alert("dsfa");alert(date.toInputFormat());
            $("#delay_date").val(date.toInputFormat());
        } else {
            alert("Invalid Date");
        }

    }
    Date.prototype.toInputFormat = function () {
        var yyyy = this.getFullYear().toString();
        var mm = (this.getMonth() + 1).toString(); // getMonth() is zero-based
        var dd = this.getDate().toString();
        return yyyy + "-" + (mm[1] ? mm : "0" + mm[0]) + "-" + (dd[1] ? dd : "0" + dd[0]); // padding
    };
    $(document).ready(function () {
        $(".bdatepicker").datepicker({
            format: "dd/mm/yyyy"
        });

        $("#invoice_date").on("change", function () {

        });


        //From: http://stackoverflow.com/questions/3066586/get-string-in-yyyymmdd-format-from-js-date-object


    });
</script>