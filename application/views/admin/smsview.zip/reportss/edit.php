<?php $locale_info = localeconv(); ?>
<script type="text/javascript">
    var supplier = '';
    var dataSupplier = "<?php print_r($suppliers); ?>";
    var delay = '';
</script>
<div class="col-md-12"><!--col-md-10 padding white right-p-->
    <div class="content">
        <?php $this->load->view('admin/common/breadcrumbs'); ?>
        <div class="row">
            <div class="col-md-12">
                <?php $this->load->view('admin/common/alert'); ?>
                <div class="module">
                    <?php echo $this->session->flashdata('message'); ?>
                    <div class="module-head">
                    </div>
                    <div class="module-body">
                        <?= form_open("admin/reportss/".$data['id']."/edit") ?>
                        <div class="row">
                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>Gross Bill Profit*</label>

                                    <div class="input-group">
                                        <span class="input-group-addon"></span>
                                        <input type="text" class="form-control" value="<?php echo $data['gross_bill']; ?>" name="gross_bill" id="gross_bill">
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>Driver*</label>

                                    <div class="input-group">
                                        <span class="input-group-addon"></span>
                                        <input type="text" class="form-control" name="driver" value="<?php echo $data['driver']; ?>" id="driver">
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>Client*</label>

                                    <div class="input-group">
                                        <span class="input-group-addon"></span>
                                        <input type="text" class="form-control" name="client" value="<?php echo $data['client']; ?>" id="client">
                                    </div>
                                </div>
                            </div>


                        </div>

                        <div class="row">
                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>Car*</label>

                                    <div class="input-group">
                                        <span class="input-group-addon"></span>
                                        <input type="text" class="form-control" name="car" value="<?php echo $data['car']; ?>" id="car">
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>Report Date*</label>

                                    <div class="input-group">
                                        <span class="input-group-addon"></span>
                                        <input type="text" class="form-control" name="report_date" value="<?php echo $data['report_date']; ?>" id="report_date">
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>Status*</label>
                                    <select class="form-control" name="status" required>
                                        <option value="<?php echo $data['status']; ?>" selected="selected"><?php echo $data['status']; ?></option>
                                        <?php foreach (config_model::$status as $key => $status): ?>
                                            <option <?= set_value('status', $this->input->post('status')) == $status ? "selected" : "" ?>
                                                value="<?= $status ?>"><?= $status ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">

                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>Over Due*</label>

                                    <div class="input-group">
                                        <span class="input-group-addon"></span>
                                        <input type="text" class="form-control" name="over_due" value="<?php echo $data['over_due']; ?>" id="over_due">
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>Invoice Id</label>
                                    <input type="text" class="form-control" name="invoice_id" value="<?php echo $data['invoice_id']; ?>" id="invoice_id">
                                </div>
                            </div>
                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>Category</label>
                                    <input type="text" class="form-control" name="category" value="<?php echo $data['category']; ?>" id="category">
                                </div>
                            </div>
                        </div>
                        <div class="row">

                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>Income</label>
                                    <input type="text" class="form-control" name="incomes" value="<?php echo $data['incomes']; ?>" id="incomes">
                                </div>
                            </div>
                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>Receivable</label>
                                    <input type="text" class="form-control" name="receivable" value="<?php echo $data['receivable']; ?>" id="receivable">
                                </div>
                            </div>
                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>Invoice number</label>
                                    <input type="text" class="form-control" name="invoice_number" value="<?php echo $data['invoice_number']; ?>" id="invoice_number">
                                </div>
                            </div>
                        </div>

                        <div class="row">

                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>Expense</label>
                                    <input type="text" class="form-control" name="expense" value="<?php echo $data['expense']; ?>" id="expense">
                                </div>
                            </div>
                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>Debits</label>
                                    <input type="text" class="form-control" name="debit" value="<?php echo $data['debit']; ?>" id="debit">
                                </div>
                            </div>

                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>Result</label>
                                    <input type="text" class="form-control" name="result" value="<?php echo $data['result']; ?>" id="result">
                                </div>
                            </div>

                        </div>

                        <div class="row">


                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>Profit</label>
                                    <input type="text" class="form-control" name="profit" value="<?php echo $data['profit']; ?>" id="profit">
                                </div>
                            </div>
                        </div>

                        <hr>
                        <div class="text-right">
                            <button class="btn btn-default">Update</button>
                            <a href="<?= base_url("admin/reportss") ?>" class="btn btn-default">Cancel</a>
                        </div>

                        <?php echo form_close(); ?>
                    </div>
                </div>
            </div>
        </div><!--/.module-->
    </div>
    <!--/.content-->
</div>

<script type="text/javascript">

    supplierData();



    function givedelayDate() {

        var date = new Date($("#invoice_date").val()),
            days = parseInt($("#delay").val(), 10);

        if (!isNaN(date.getTime())) {
            date.setDate(date.getDate() + days);
// alert("dsfa");alert(date.toInputFormat());
            $("#delay_date").val(date.toInputFormat());
        } else {
            alert("Invalid Date");
        }

    }
    Date.prototype.toInputFormat = function () {
        var yyyy = this.getFullYear().toString();
        var mm = (this.getMonth() + 1).toString(); // getMonth() is zero-based
        var dd = this.getDate().toString();
        return yyyy + "-" + (mm[1] ? mm : "0" + mm[0]) + "-" + (dd[1] ? dd : "0" + dd[0]); // padding
    };
    $(document).ready(function () {
        $(".bdatepicker").datepicker({
            format: "dd/mm/yyyy"
        });

        $("#invoice_date").on("change", function () {

        });


        //From: http://stackoverflow.com/questions/3066586/get-string-in-yyyymmdd-format-from-js-date-object


    });
</script>