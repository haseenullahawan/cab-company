<?php $locale_info = localeconv(); ?>
<script type="text/javascript">
    var supplier = '';
    var dataSupplier = "<?php print_r($suppliers); ?>";
    var delay = '';
</script>
<div class="col-md-12"><!--col-md-10 padding white right-p-->
    <div class="content">
        <?php $this->load->view('admin/common/breadcrumbs'); ?>
        <div class="row">
            <div class="col-md-12">
                <?php $this->load->view('admin/common/alert'); ?>
                <div class="module">
                    <?php echo $this->session->flashdata('message'); ?>
                    <div class="module-head">
                    </div>
                    <div class="module-body">
                        <?= form_open("admin/bank/add") ?>
                        <div class="row">
                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>Status*</label>
                                    <select class="form-control" name="status" required>
                                        <?php foreach (config_model::$status as $key => $status): ?>
                                            <option <?= set_value('status', $this->input->post('status')) == $status ? "selected" : "" ?>
                                                value="<?= $status ?>"><?= $status ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>Client*</label>

                                    <div class="input-group">
                                        <span class="input-group-addon"></span>
                                        <input type="text" class="form-control" name="client" id="client">
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>Invoice number</label>
                                    <input type="text" class="form-control" name="invoice_number" id="invoice_number">
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>Description*</label>

                                    <div class="input-group">
                                        <span class="input-group-addon"></span>
                                        <input maxlength="50" type="text" class="form-control" required
                                               name="description" id="description" ">

                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>Credit</label>
                                    <input type="text" class="form-control" name="credit" id="credit">
                                </div>
                            </div>
                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>Debit*</label>

                                    <div class="input-group">
                                        <span class="input-group-addon"></span>
                                        <input maxlength="50" type="text" class="form-control" required
                                               name="debit" id="debit" placeholder="debit">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">

                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>Category*</label>

                                    <div class="input-group">
                                        <span class="input-group-addon"></span>
                                        <input maxlength="50" type="text" class="form-control" required
                                               name="category" id="category" placeholder="category">
                                    </div>
                                </div>
                            </div>


                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>Vat</label>

                                    <div class="input-group">
                                        <span class="input-group-addon"></span>
                                        <input id="vat" type="text" class="form-control" required
                                               name="vat">
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>Bill Invoice*</label>

                                    <div class="input-group">
                                        <span class="input-group-addon"></span>
                                        <input  type="text" class="form-control" required
                                               name="bill_invoice" id="v" placeholder="bill_invoice">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="text-right">
                            <button class="btn btn-default">Save</button>
                            <a href="<?= base_url("admin/bank") ?>" class="btn btn-default">Cancel</a>
                        </div>

                        <?php echo form_close(); ?>
                    </div>
                </div>
            </div>
        </div><!--/.module-->
    </div>
    <!--/.content-->
</div>

<script type="text/javascript">

    supplierData();



    function givedelayDate() {

        var date = new Date($("#invoice_date").val()),
            days = parseInt($("#delay").val(), 10);

        if (!isNaN(date.getTime())) {
            date.setDate(date.getDate() + days);
// alert("dsfa");alert(date.toInputFormat());
            $("#delay_date").val(date.toInputFormat());
        } else {
            alert("Invalid Date");
        }

    }
    Date.prototype.toInputFormat = function () {
        var yyyy = this.getFullYear().toString();
        var mm = (this.getMonth() + 1).toString(); // getMonth() is zero-based
        var dd = this.getDate().toString();
        return yyyy + "-" + (mm[1] ? mm : "0" + mm[0]) + "-" + (dd[1] ? dd : "0" + dd[0]); // padding
    };
    $(document).ready(function () {
        $(".bdatepicker").datepicker({
            format: "dd/mm/yyyy"
        });

        $("#invoice_date").on("change", function () {

        });


        //From: http://stackoverflow.com/questions/3066586/get-string-in-yyyymmdd-format-from-js-date-object


    });
</script>