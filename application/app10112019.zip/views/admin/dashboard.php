<style>
    .dataTables_length, .dataTables_filter, .dataTables_info, .dataTables_paginate {
        display: none;
    }
    .module-head h2 {
        font-size: 18px; padding: 5px 0; margin: 0;
    }
    .module {
        border: 1px solid #ccc;
        border-radius: 5px;
        margin: 20px 0;
        padding-bottom: 15px;
    }
    .module .btn {
        margin-left: 10px;
    }
    .btn-mar {
        margin-top: 35px;
    }
</style>
<div class="col-xs-12 padding right-p dashboard">
    <div class="content">
        <?php $this->load->view('admin/common/breadcrumbs');?>
        <div class="row">
            <div class="col-md-4">
                <div class="module">
                    <div class="module-head">
                        <h2 class="grad-bg text-center">Quote Requests:</h2>
                    </div>
                    <div class="module-body">
                        <table class="table table-bordered">
                            <tbody>
                            <tr>
                                <th><?php echo $this->lang->line('new');?>: </th>
                                <td><?=isset($request['new']) ? $request['new'] : 0?></td>
                            </tr>
                            <tr>
                                <th><?php echo $this->lang->line('pending');?>: </th>
                                <td><?=isset($request['pending']) ? $request['pending'] : 0?></td>
                            </tr>
                            <tr>
                                <th><?php echo $this->lang->line('replied');?>: </th>
                                <td><?=isset($request['replied']) ? $request['replied'] : 0?></td>
                            </tr>
                            <tr>
                                <th><?php echo $this->lang->line('closed');?>: </th>
                                <td><?=isset($request['closed']) ? $request['closed'] : 0?></td>
                            </tr>
                            </tbody>
                        </table>
                        <a href="<?=base_url("admin/request")?>" class="btn btn-default btn-mar">Go to Quote Requests</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="module">
                    <div class="module-head">
                        <h2 class="grad-bg text-center">Calls:</h2>
                    </div>
                    <div class="module-body">
                        <table class="table table-bordered">
                            <tbody>
                            <tr>
                                <th><?php echo $this->lang->line('new');?>: </th>
                                <td><?=isset($calls['new']) ? $calls['new'] : 0?></td>
                            </tr>
                            <tr>
                                <th><?php echo $this->lang->line('pending');?>: </th>
                                <td><?=isset($calls['pending']) ? $calls['pending'] : 0?></td>
                            </tr>
                            <tr>
                                <th><?php echo $this->lang->line('replied');?>: </th>
                                <td><?=isset($calls['replied']) ? $calls['replied'] : 0?></td>
                            </tr>
                            <tr>
                                <th><?php echo $this->lang->line('closed');?>: </th>
                                <td><?=isset($calls['closed']) ? $calls['closed'] : 0?></td>
                            </tr>
                            </tbody>
                        </table>
                        <a href="<?=base_url("admin/calls")?>" class="btn btn-default btn-mar">Go to Calls</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="module">
                    <div class="module-head">
                        <h2 class="grad-bg text-center">Job Applications:</h2>
                    </div>
                    <div class="module-body">
                        <table class="table table-bordered">
                            <tbody>
                            <tr>
                                <th><?php echo $this->lang->line('new');?>: </th>
                                <td><?=isset($jobs['new']) ? $jobs['new'] : 0?></td>
                            </tr>
                            <tr>
                                <th><?php echo $this->lang->line('pending');?>: </th>
                                <td><?=isset($jobs['pending']) ? $jobs['pending'] : 0?></td>
                            </tr>
                            <tr>
                                <th><?php echo $this->lang->line('meeting');?>: </th>
                                <td><?=isset($jobs['meeting']) ? $jobs['meeting'] : 0?></td>
                            </tr>
                            <tr>
                                <th><?php echo $this->lang->line('accepted');?>: </th>
                                <td><?=isset($jobs['accepted']) ? $jobs['accepted'] : 0?></td>
                            </tr>
                            <tr>
                                <th><?php echo $this->lang->line('denied');?>: </th>
                                <td><?=isset($jobs['denied']) ? $jobs['denied'] : 0?></td>
                            </tr>
                            </tbody>
                        </table>
                        <a href="<?=base_url("admin/jobs")?>" class="btn btn-default">Go to Job Applications</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--/.content-->
</div>
<!--/.span9-->
</div>
<!--/.container-->
</div>
<!--/.wrapper-->