
<div class="main-hed">
    <a href="<?php echo site_url();?>/admin/dashboard">Home</a>
    <?php if(isset($title)) {
        echo " >> ";
        echo isset($title_link) ? "<a href='" . $title_link . "'>$title</a>" : $title;
    } ?>
    <?php if(isset($subtitle)) echo " >> ".$subtitle;?>
</div>