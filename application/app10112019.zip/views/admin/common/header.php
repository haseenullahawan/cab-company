<?php
$page_lang = 'lang="fr"';
?>
<!DOCTYPE html>
<html <?php echo $page_lang;?>>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="<?php if (isset($meta_keywords)) echo $meta_keywords; ?>"/>
    <meta name="description" content="<?php if (isset($meta_description)) echo $meta_description; ?>" />
    <link rel='shortcut icon' href='<?php echo base_url(); ?>assets/system_design/images/favicon.ico' type='image/x-icon'/>
    <title><?php echo $title; ?></title>
    <!-- Bootstrap -->
    <link href="<?php echo base_url(); ?>assets/system_design/css/buttons.dataTables.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/system_design/css/styles.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/system_design/css/callback.css" rel="stylesheet">
    <?php if (isset($site_settings->site_theme) && $site_settings->site_theme == "Red") { ?>
        <link href="<?php echo base_url(); ?>assets/system_design/css/cab-2ntheame.css" rel="stylesheet">
    <?php } else { ?>
        <link href="<?php echo base_url(); ?>assets/system_design/css/cab.css" rel="stylesheet">
        <link href="<?php echo base_url(); ?>assets/system_design/css/custom-style.css" rel="stylesheet">

    <?php } ?>
    <link href="<?php echo base_url(); ?>assets/system_design/css/bootstrap-datepicker.min.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->	<script src="<?php echo base_url(); ?>assets/system_design/scripts/jquery.js"></script>
    <script src="<?php echo base_url(); ?>/assets/system_design/form_validation/js/jquery.validate.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>/assets/system_design/form_validation/js/additional-methods.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>/assets/system_design/ckeditor.js" type="text/javascript"></script>
    <style>
        .unread {
            background-color: #eee !important;
        }
        input[type="text"] {
            height: 36px;
        }
        .form-group {
            padding-bottom: 10px !important;
        }
        .form-control {
            float: none;
        }
        div.dt-buttons {
            float: right;
        }
        .navbar-nav.menu li a {
            padding: 19px 14.5px 15px 14.5px;
        }
        table.dataTable thead th {
            border-right: 1px solid #ccc;
            white-space: nowrap;
        }
    </style>
    <style>
        .close span {
            text-indent: 0;
            display: inline;
        }
        .btn-circle {
            border-radius: 50%;
            margin-right: 5px;
        }
        .btn-circle.btn-sm {
            padding: 2px 6px;
            margin-top: 5px;
            outline: none;
        }
        #noteDIv .row {
            margin-bottom: 10px;
        }
        #attachDiv input[type='file'] {
            margin-top: 5px;
            outline: none;
        }
        .dataTables_wrapper .dataTables_filter input {
            margin-right: 2px;
            margin-left: 0 !important;
            max-width: 86px !important;
            width: 100% !important;
            float: right;
        }
        .toolbar {
            float:right;
            margin-right: 4px;
        }
        .dataTables_wrapper .dataTables_paginate .paginate_button.current, .dataTables_wrapper .dataTables_paginate .paginate_button.current:hover {
            background: #fefefe;
        }
        .table-filter {
        }
        .table-filter input, .table-filter select{
            max-width: 6.6%;
            float: left;
            width: 100%;
            height: 32px !important;
            padding: 2px !important;
            margin-right: 2px !important;
            font-size: 12px;
        }
        .table-filter select{
            max-width: 80px;
        }
        .table-filter .dpo {
            max-width: 98px;
        }
        .attach-label {
            padding-top: 10px; width: 18%; float: left; text-align: center;
        }
        .attach-div {
            padding-top: 5px;display: inline-block; width: 82%; float: right; text-align: right;
        }
        .attach-file {
            overflow: hidden; width: 75%; float: left
        }
        .attach-buttons {
            width: 25%; float: right
        }
        .normal-addon {
            border: 0;
            background: #f5f5f5 !important;
        }
    </style>
</head>
<body>
<header>
    <div class="header-wrapper">
        <div class="navbar-fixed-top">
            <div class="top-section">
                <div class="container-fluid">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-6 col-sm-6 col-xs-12 section-cen">               <?php ?>

                                <?php if (!$this->ion_auth->logged_in()) { ?>
                                    <div class="social-icons left" style="margin-top:4px; margin-right: 10px !important">
                                        <a class="top-login" href="#" data-href="<?php echo site_url(); ?>chauffeur.php"><?php echo $this->lang->line('driver_login');?></a>
                                    </div>

                                <?php } ?>
                                <div class="social-icons left">
                                    <ul>
                                        <?php
                                        $social_networks = $this->base_model->run_query("SELECT * FROM vbs_social_networks");

                                        //social_networks

                                        if (isset($social_networks[0]->facebook)) {
                                            ?>
                                            <li>
                                                <a href="<?php echo $social_networks[0]->facebook; ?>"   target="_blank">
                                                    <img src='<?php echo base_url() . "assets/system_design/images/facebook-icon.png" ?>' alt="Navetteo Facebook" title="Navetteo Facebook" />
                                                </a> <!--<i class="fa fa-facebook"></i>-->
                                            </li>
                                        <?php }
                                        if (isset($social_networks[0]->twitter)) {
                                            ?>
                                            <li>
                                                <a href="<?php echo $social_networks[0]->twitter; ?>"   target="_blank">
                                                    <!--<i class="fa fa-twitter"></i> -->
                                                    <img src='<?php echo base_url() . "assets/system_design/images/twitter-icon.png" ?>' alt="Navetteo Twitter" title="Navetteo Twitter"/>
                                                </a>
                                            </li>
                                        <?php   }
                                        if (isset($social_networks[0]->linkedin)) {
                                            ?>
                                            <li>
                                                <a href="<?php echo $social_networks[0]->linkedin; ?>"  target="_blank">
                                                    <!--<i class="fa fa-linkedin"></i>  -->
                                                    <img src='<?php echo base_url() . "assets/system_design/images/linkedin-icon.png" ?>' alt="Navetteo LinkedIn" title="Navetteo LinkedIn"/>
                                                </a>
                                            </li>
                                        <?php }
                                        if (isset($social_networks[0]->google_plus)) {
                                            ?>
                                            <li>
                                                <a href="<?php echo $social_networks[0]->google_plus; ?>" target="_blank">
                                                    <!--<i class="fa fa-google-plus"></i> -->
                                                    <img src='<?php echo base_url() . "assets/system_design/images/google-icon.png" ?>' alt="Navetteo GooglePlus" title="Navetteo GooglePlus"/>
                                                </a>

                                            </li>
                                        <?php   } ?>

                                    </ul>
                                </div>
                                <div class="top-pack-book-links <?php if( $this->lang->lang() == 'fr' ) { echo 'leftalign_fr'; } else { echo 'leftalign_en'; } ?>">
                                    <ul>
                                        <li><a class="bookmark" href="javascript:(function(){var a=window,b=document,c=encodeURIComponent,d=a.open('http://www.seocentro.com/cgi-bin/promotion/bookmark/bookmark.pl?u='+c( b.location )+'&amp;t='+c( b.title ),'bookmark_popup','left='+((a.screenX||a.screenLeft)+10)+',top='+((a.screenY||a.screenTop)+10)+',height=480px,width=720px,scrollbars=1,resizable=1,alwaysRaised=1');a.setTimeout(function(){ d.focus()},300)})();"><?php echo $this->lang->line('bookmark_us');?></a></li>
                                    </ul>
                                </div>
                            </div>


                            <div class="col-md-6 col-sm-6 col-xs-12 section-ce2">

                                    <a href="<?php echo site_url(); ?>/auth" >
                                        <div class="right">
                                            <div class="tot-top">
                                                <div class="phone"> <i class="fa fa-user"></i> </div>
                                                <a data-toggle="dropdown" class="dropdown-toggle" href="#" aria-expanded="false"> <?= $user->username; ?><b class="caret"></b></a>
                                                <ul class="dropdown-menu">
                                                    <li><a href="#"><i class="fa fa-fw fa-desktop"></i> CMS</a></li>
                                                    <li><a href="#"><i class="fa fa-fw fa-wrench"></i> Configurations</a></li>
                                                    <li><a href="#"><i class="fa fa-fw fa-gear"></i> Settings</a></li>                                                   <li><a href="<?php echo base_url('admin/company'); ?>"><i class="fa fa-fw fa-file"></i> Company Profile</a></li>
                                                    <li><a href="<?php echo base_url('admin/departments'); ?>"><i class="fa fa-fw fa-table"></i> Departments</a></li>
                                                    <li><a href="<?php echo base_url('admin/roles'); ?>"><i class="fa fa-fw fa-tag"></i> Roles</a></li>
                                                    <li><a href="<?php echo base_url('admin/users'); ?>"><i class="fa fa-fw fa-users"></i> Users</a></li>
                                                    <li> <a href="<?php echo site_url(); ?>admin/logout"><i class="fa fa-fw fa-power-off"></i><?php echo $this->lang->line('log_out'); ?> </a> </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </a>

                                <div class="lang-icons"><!--class="selec" id="uli"-->
                                    <ul class="right">
                                        <li> <a href="<?php echo base_url() . $this->lang->switch_uri('en') ?>"><span class="en-icon"></span></a> </li>
                                        <li><a href="<?php echo base_url() . $this->lang->switch_uri('fr') ?>"><span class="fr-icon"></span></a></li>
                                    </ul>
                                </div>

                                <div class="audio right">
                                    <object class="audioObj"  width="140" height="14" style=" float: right;margin-left: 20px;vertical-align: top;" data="http://flash-mp3-player.net/medias/player_mp3_mini.swf" type="application/x-shockwave-flash" title="Adobe Flash Player">
                                        <param value="http://flash-mp3-player.net/medias/player_mp3_mini.swf" name="movie">
                                        <param value="#5590C1" name="bgcolor">
                                        <?php   if( $this->lang->lang() == 'fr' ) { ?>
                                            <param value="mp3=<?php echo base_url(); ?>assets/system_design/audio/navetteo_french.mp3&amp;bgcolor=0D528A&amp;slidercolor=fb833e&amp;autoplay=1&amp;autoload=0" name="FlashVars">
                                        <?php   }
                                        else {
                                            ?>          <param value="mp3=<?php echo base_url(); ?>assets/system_design/audio/navetteo_english.mp3&amp;bgcolor=0D528A&amp;slidercolor=fb833e&amp;autoplay=1&amp;autoload=0" name="FlashVars">
                                        <?php   } ?>
                                    </object>
                                </div>
                                <?php   if ($site_settings->app_settings == "Enable") { ?>
                                    <div class="top-links">
                                        <a href="<?php echo site_url(); ?>/welcome/download_app/android"><img src="<?php echo base_url(); ?>assets/system_design/images/header/google-play-icon.png" style="width:48%" alt="Navetteo Google Apps" title="Navetteo Google Apps " /></a>
                                        <a href="<?php echo site_url(); ?>/welcome/download_app/ios"><img src="<?php echo base_url(); ?>assets/system_design/images/header/apple-icon.png" style="width:48%" alt="Navetteo iPhone Apps" title="Navetteo iPhone Apps"/></a>
                                    </div>
                                <?php   } ?>

                            </div><!-- end collumn-->
                        </div> <!--end row-->
                    </div>
                </div>
            </div>

            <div class="container-fluid secondary-header">
                <div class="container"><!-- padding-p-0-->
                    <div class="row">
                        <div class="col-md-2"> <!--padding-p-l-->
                            <a href="<?php echo site_url();?>index.php">
                                <div class="logo"><img src="<?php echo base_url(); ?>assets/system_design/images/new_footer_header_images/logo.png" alt="Handi Mobilite Logo" title="Handi Mobilite Logo" style="width:200px;height:140px;"/></div>
                            </a>
                        </div>
                        <div class="col-md-9 padding-p-r">

                            &nbsp;&nbsp;
                            <?php   if ($this->lang->lang() == 'fr') { ?>
                                <div class="col-md-4 right french-contact-number"><!--padding-p-r-->
                                    <?php   //$phone = $site_settings->land_line;
                                    echo "01 48 13 09 34";

                                    ?>
                                    <p class="working-hours" style=" left:35px;">Du Lundi au Vendredi <br/>de 9h à 12h et de 14h à 18h</p>


                                </div>
                            <?php   } else { ?>
                                <div class="col-md-4 right english-contact-number">
                                    <?php //    $phone = $site_settings->phone;
                                    echo "01 48 13 09 34";
                                    ?>
                                    <p class="working-hours" style="left:20px;">From Monday to Friday <br/>9h to 12h and from 14h to 18h</p>
                                </div>
                            <?php   }   ?>
                            <div class="col-md-1 right">


                                <img src="<?php echo base_url(); ?>assets/system_design/images/call-us-girl.png" class="call-us-girl" alt="Call Us" title="Call Us" /></div>
                            <?php if ($this->lang->lang() == 'fr') { ?>
                                <div class="header-icons-fr">

                                    <img src="<?php echo base_url(); ?>assets/system_design/images/new_footer_header_images/logo1ssside.png" alt="Aeroport Service"  width="250px" height="80px"  title="Aeroport Service"/>

                                    <img src="<?php echo base_url(); ?>assets/system_design/images/new_footer_header_images/logoagain.png" alt="Aeroport Service"  width="250px" height="80px"  title="Aeroport Service"/>



                                    <img src="<?php echo base_url(); ?>assets/system_design/images/new_footer_header_images/disable.png" alt="Aeroport Service"  width="250px" height="80px" title="Aeroport Service"/>


                                </div>
                            <?php   }
                            else if ($this->lang->lang() == 'en') { ?>
                                <div class="header-icons-en">
                                    <img src="<?php echo base_url(); ?>assets/system_design/images/header/aeroport.png" alt="Airport Service" title="Airport Service"/>
                                    <img src="<?php echo base_url(); ?>assets/system_design/images/header/passengers.png" alt="Passengers" title="Passengers"/>
                                    <img src="<?php echo base_url(); ?>assets/system_design/images/header/circuit-touristiques.png" alt="Tours Circuit" title="Tours Circuit"/>
                                    <img src="<?php echo base_url(); ?>assets/system_design/images/header/transfert-gare.png" alt="Railway Transfer" title="Railway Transfer"/>
                                    <img src="<?php echo base_url(); ?>assets/system_design/images/header/airport-transfers.png" style="width:95px" alt="Airport Transfer" title="Airport Transfer"/>
                                    <img src="<?php echo base_url(); ?>assets/system_design/images/header/free-quotes-en.png" alt="Free Quotes" title="Free Quotes"/>
                                    <img src="<?php echo base_url(); ?>assets/system_design/images/header/24hr-fr.png" alt="24/7 Service" title="24/7 Service"/>
                                    <img src="<?php echo base_url(); ?>assets/system_design/images/header/disabled.png" alt="Disabled" title="Disabled"/>
                                </div>
                            <?php   }   ?>
                        </div>

                    </div>
                </div>
            </div> <!--/.container-fluid -->
            <div class="main-menu" style="height: 70px">
                <div class="container nav-border">
                    <div class="row">
                        <nav class="navbar navbar-navetteo menu-total">
                            <div class="navbar-header">
                                <button aria-controls="navbar" aria-expanded="false" data-target="#navbar" data-toggle="collapse" class="navbar-toggle collapsed nav-bar-btn" type="button"> <span class="sr-only"><?php echo $this->lang->line('toggle_navigation');?></span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
                            </div>
                            <div class="collapse navbar-collapse res-menu" id="navbar">
                                <ul class="nav navbar-nav menu">
                                    <li <?php if(isset($active_class)){ if($active_class=="dashboard") echo 'class="active"'; }?>><a href="<?php echo site_url();?>admin/dashboard"><span><?php echo $this->lang->line('dashboard');?></span></a></li>
                                    <li <?php if(isset($active_class)){ if($active_class=="request") echo 'class="active"'; }?>><a href="<?php echo site_url('admin/request');?>">Quotes Requests</a></li>
                                    <li <?php if(isset($active_class)){ if($active_class=="calls") echo 'class="active"'; }?>><a href="<?php echo site_url('admin/calls');?>"><span><?php echo $this->lang->line('calls');?></span></a></li>
                                    <li <?php if(isset($active_class)){ if($active_class=="jobs") echo 'class="active"'; }?>><a href="<?php echo site_url('admin/jobs');?>"><span><?php echo $this->lang->line('jobs');?></span></a></li>
                                    <li <?php if(isset($active_class)){ if($active_class=="booking") echo 'class="active"'; }?>><a href="#">Bookings</a></li>
                                    <li <?php if(isset($active_class)){ if($active_class=="support") echo 'class="active"'; }?>><a href="#"><span><?php echo $this->lang->line('support');?></span></a></li>
                                    <li <?php if(isset($active_class)){ if($active_class=="invoices") echo 'class="active"'; }?>><a href="#">Invoices</a></li>
                                    <li <?php if(isset($active_class)){ if($active_class=="clients") echo 'class="active"'; }?>><a href="#">Clients</a></li>
                                    <li <?php if(isset($active_class)){ if($active_class=="drivers") echo 'class="active"'; }?>><a href="#">Drivers</a></li>
                                    <li <?php if(isset($active_class)){ if($active_class=="planning") echo 'class="active"'; }?>><a href="#">Planning</a></li>
                                    <li <?php if(isset($active_class)){ if($active_class=="cars") echo 'class="active"'; }?>><a href="#">Cars</a></li>
                                    <li <?php if(isset($active_class)){ if($active_class=="map") echo 'class="active"'; }?>><a href="#">Map</a></li>
                                </ul>
                            </div>
                            <!--/.nav-collapse -->
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
