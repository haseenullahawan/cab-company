</div>
</div>
<section class="footer-top">
    <div class="container">
        <div class="row">
            <div class="col-md-3 col-sm-3 text-center">
                <a href="<?php echo site_url();?>contact.php"><span class="send-us-email"><i class="fa fa-envelope"></i> contact@handi-express.fr</span></a>
            </div>
            <div class="col-md-3 col-sm-3 text-center">
                <span class="call-us"><i class="fa fa-phone"></i> Fax 0183628404</span>
            </div>
            <div class="col-md-3 col-sm-3 text-center">
                <span class="live-support"><i class="fa fa-wechat"></i> Live Support</span>
            </div>
            <div class="col-md-3 col-sm-3 text-center">
                <a href="<?php echo site_url();?>supporttickets.php"><span class="ticket-support"><i class="fa fa-headphones"></i> Ticket Support</span></a>
            </div>
        </div>
    </div>
</section>
<section class="footer">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-3 col-sm-6" style="width:33%;">
                <div class="logo2"><img src="<?php echo base_url(); ?>assets/system_design/images/new_footer_header_images/footerlogo.png" alt="Handi Express Logo" title="Handi Express Logo" /></div>
                <div class="copyright-left">
                    <?php //    if(isset($site_settings->rights_reserved_content)) { ?>
                    <p>Copyright France © 2010 Handi-Express.fr Tous droits reservés</p>
                    <?php //} ?>
                </div>
                <p class="credit-cards"><!--<label><?php echo $this->lang->line('cards_we_accept');?></label>--><img src="<?php echo base_url();?>/assets/system_design/images/credit-cards-logos.png" alt="All Cards we accept" title="All Cards we accept" /></p>
                <p style="float:left"><a href="http://www.copyrightfrance.com/certificat-depot-copyright-france-28RF1G2.htm" target="_BLANK"><img src="<?php echo base_url();?>/assets/system_design/images/copyright-logo.gif" style="margin-top: 5px;margin-left: 0px" alt="Copyrights" title="Copyrights" /></a></p>
            </div>
            <div class="col-lg-9 col-md-9 col-sm-6" style="width:67%;">
                <div class="row">
                    <div class="col-lg-3 col-md-3 col-sm-4">
                        <div class="footer_div">
                            <div class="footer_heading">
                                <h5>TRANSPORT PMR REGULIER  <?php echo $this->lang->line('transport_shuttle');?></h5>
                            </div>
                            <!--./footer_heading-->
                            <div class="footer_links">
                                <ul>
                                    <li> <a href="<?php echo site_url();?>handi-pro.php">HANDI PRO</a></li>
                                    <li><a href="<?php echo site_url();?>handi-business.php">HANDI BUSINESS</a></li>

                                    <li><a href="<?php echo site_url();?>handi-soclaire.php">HANDI SCOLAIRE</a></li>


                                </ul>
                            </div>
                        </div>
                        <!--./footer_div-->
                    </div>

                    <div class="col-lg-3 col-md-3 col-sm-4">
                        <div class="footer_div">
                            <div class="footer_heading">
                                <h5>TRANSPORT PMR A LA DEMANDE</h5>
                            </div>
                            <!--./footer_heading-->
                            <div class="footer_links">
                                <ul>
                                    <li><a href="<?php echo site_url();?>handi-prive.php">HANDI PRIVE</a></li>
                                    <li><a href="<?php echo site_url();?>handi-shuttle.php">HANDI SHUTTLE</a></li>
                                    <li><a href="<?php echo site_url();?>handi-voyage.php">HANDI VOYAGE</a></li>
                                    <li><a href="<?php echo site_url();?>handi-senior.php">HANDI SENIOR</a></li>
                                    <li><a href="<?php echo site_url();?>handi-medical.php"> HANDI MEDICAL</a></li>
                                </ul>
                            </div>
                        </div>
                        <!--./footer_div-->
                    </div>


                    <div class="col-lg-3 col-md-3 col-sm-4">
                        <div class="footer_div">
                            <div class="footer_heading">
                                <h5>INFORMATION<?php echo $this->lang->line('transport_gare');?></h5>
                            </div>
                            <!--./footer_heading-->
                            <div class="footer_links">
                                <ul>
                                    <li> <a href="<?php echo site_url();?>nos-tarifs.php">Tarifs </a></li>

                                    <li> <a href="<?php echo site_url();?>contact.php">Nous Contacter</a></li>

                                </ul>
                            </div>
                        </div>
                        <!--./footer_div-->
                    </div>

                    <div class="col-lg-3 col-md-3 col-sm-3">
                        <div class="footer_div">
                            <div class="footer_heading">
                                <h5><?php echo $this->lang->line('usefullinks_page');?></h5>
                            </div>
                            <div class="footer_links">
                                <ul>
                                    <li><a href="<?php echo site_url(); ?>zones.php"><?php echo $this->lang->line('zones_page');?></a></li>
                                    <li><a href="<?php echo site_url(); ?>vehicules.php"><?php echo $this->lang->line('page_fleet');?></a></li>
                                    <li><a href="<?php echo site_url(); ?>knowledgebase.php"><?php echo $this->lang->line('FAQs');?></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--./container-->
</section>
<section class="bottom_footer">
    <div class="container">

        <div class="col-md-3  padding-lr">
            <div class="footer-quick-links">
                <ul>
                    <li>Developed by <a href="http://netsco.biz" target="_BLANK">NETSCO</a></li>
                </ul>
            </div>
        </div>

        <div class="col-md-8  ">
            <div class="footer-quick-links">
                <ul>
                    <li><a href="<?php echo site_url();?>conditions-d-utilisation.php"><?php echo $this->lang->line('terms_conditions');?></a></li>
                    <li><a href="<?php echo site_url();?>politique-de-vie-privee.php"><?php echo $this->lang->line('privacy_policy');?></a></li>
                    <li><a href="<?php echo site_url();?>contact.php"><?php echo $this->lang->line('report_abuse');?></a></li>
                    <li><a href="<?php echo site_url();?>mentions-legales.php"><?php echo $this->lang->line('legal_notice');?></a></li>
                </ul>
            </div>
        </div>
    </div>
</section>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->

<!-- Include all compiled plugins (below), or include individual files as needed -->

<script src="<?php echo base_url();?>assets/system_design/scripts/chosen.jquery.min.js"></script>

<script>
    $(function() {
        $(".chzn-select").chosen();
    });
</script>

<script src="<?php echo base_url(); ?>assets/system_design/scripts/moment.min.js"></script>
<script src="<?php echo base_url();?>assets/system_design/scripts/bootstrap.min.js"></script>
<!--<script src="<?php echo base_url();?>assets/system_design/scripts/BeatPicker.min.js"></script>-->
<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
<script src="<?php echo base_url();?>assets/system_design/scripts/timepicki.js"></script>
<script src="<?php echo base_url();?>assets/system_design/scripts/bx-slider.js"></script>
<script src="<?php echo base_url(); ?>assets/system_design/scripts/bootstrap-datepicker.min.js"></script>
<script>
    $('#timepicker1').timepicki({
        show_meridian:false,
        min_hour_value:0,
        max_hour_value:23,
        overflow_minutes:true,
        increase_direction:'up',
        disable_keyboard_mobile: true});
    $('#timepicker2').timepicki({
        show_meridian:false,
        min_hour_value:0,
        max_hour_value:23,
        overflow_minutes:true,
        increase_direction:'up',
        disable_keyboard_mobile: true});
    $('#go_time_1, #back_time_1').timepicki({show_meridian:false,min_hour_value:0,max_hour_value:23,overflow_minutes:true,increase_direction:'up',disable_keyboard_mobile: true});
    $('#go_time_2, #back_time_2').timepicki({show_meridian:false,min_hour_value:0,max_hour_value:23,overflow_minutes:true,increase_direction:'up',disable_keyboard_mobile: true});
    $('#go_time_3, #back_time_3').timepicki({show_meridian:false,min_hour_value:0,max_hour_value:23,overflow_minutes:true,increase_direction:'up',disable_keyboard_mobile: true});
    $('#go_time_4, #back_time_4').timepicki({show_meridian:false,min_hour_value:0,max_hour_value:23,overflow_minutes:true,increase_direction:'up',disable_keyboard_mobile: true});
    $('#go_time_5, #back_time_5').timepicki({show_meridian:false,min_hour_value:0,max_hour_value:23,overflow_minutes:true,increase_direction:'up',disable_keyboard_mobile: true});
    $('#go_time_6, #back_time_6').timepicki({show_meridian:false,min_hour_value:0,max_hour_value:23,overflow_minutes:true,increase_direction:'up',disable_keyboard_mobile: true});
    $('#go_time_7, #back_time_7').timepicki({show_meridian:false,min_hour_value:0,max_hour_value:23,overflow_minutes:true,increase_direction:'up',disable_keyboard_mobile: true});

</script>
<?php if(in_array("homebooking",$css_type)) { ?>

    <?php echo $this->load->view('site/common/script'); ?>

<?php } ?>

<?php if(in_array("onlinebooking",$css_type) || in_array("passengerdetails",$css_type)) { ?>

    <?php echo $this->load->view('site/common/online_script'); ?>

<?php } ?>
<script src="<?php echo base_url(); ?>assets/system_design/plugins/summernote/summernote.min.js"></script>

<!--Date Table-->
<?php if(in_array("datatable",$css_type)) { ?>
    <script src="<?php echo base_url();?>assets/system_design/scripts/datatables/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url();?>assets/system_design/scripts/datatables/dataTables.buttons.min.js"></script>
    <script src="<?php echo base_url();?>assets/system_design/scripts/datatables/jszip.min.js"></script>
    <script src="<?php echo base_url();?>assets/system_design/scripts/datatables/pdfmake.min.js"></script>
    <script src="<?php echo base_url();?>assets/system_design/scripts/datatables/vfs_fonts.js"></script>
    <script src="<?php echo base_url();?>assets/system_design/scripts/datatables/buttons.html5.min.js"></script>
    <script class="init">
        function toDate(dateStr) {
            var parts = dateStr.split("/");
            return new Date(parts[2], parts[1] - 1, parts[0])
        }
        // Date range filter
        var minDateFilter = "";
        var maxDateFilter = "";

        var minAgeFilter = "";
        var maxAgeFilter = "";

        var dateIndex = $("#example thead").find(".column-date").index();
        $.fn.dataTableExt.afnFiltering.push(
            function(oSettings, aData, iDataIndex) {
                if($("#table-filter .dpo").length > 0) {
                    if (typeof aData._date == 'undefined') {
                        aData._date = toDate(aData[dateIndex]).getTime();
                    }

                    if (minDateFilter && !isNaN(minDateFilter)) {
                        //console.log(aData._date);
                        //console.log(minDateFilter);
                        //console.log("min");
                        //console.log(aData._date < minDateFilter);
                        if (aData._date < minDateFilter) {
                            return false;
                        }
                    }

                    if (maxDateFilter && !isNaN(maxDateFilter)) {

                        //console.log(maxDateFilter);
                        //console.log(aData._date);
                        //console.log("max")
                        //console.log(aData._date > maxDateFilter);
                        if (aData._date > maxDateFilter) {
                            return false;
                        }
                    }
                }

                return true;
            }
        );

        var ageIndex = $("#example thead").find(".column-age").index();
        $.fn.dataTable.ext.search.push(
            function( settings, data, dataIndex ) {
                var min = parseInt( $('.table-filter input[data-name="age_from"]').val(), 10 );
                var max = parseInt( $('.table-filter input[data-name="age_to"]').val(), 10 );
                var age = parseFloat( data[ageIndex] ) || 0; // use data for the age column

                if( ( isNaN( min ) && isNaN( max ) ) ||
                    ( isNaN( min ) && age <= max ) ||
                    ( min <= age   && isNaN( max ) ) ||
                    ( min <= age   && age <= max ) )
                {
                    return true;
                }
                return false;
            }
        );

        if($("#example thead").find(".column-first_name").length > 0) {
            $.fn.dataTable.ext.search.push(
                function (settings, data, dataIndex) {
                    var firstNameIndex = $("#example thead").find(".column-first_name").index();
                    var lastNameIndex = $("#example thead").find(".column-last_name").index();
                    var sName = $(document.body).find('.table-filter input[data-name="name"]').val();
                    var fnRegex = new RegExp(sName, 'i');
                    var fName = data[firstNameIndex].replace(/[^\w\s]|_/g, function ($1) {
                        return ' ' + $1 + ' ';
                    }).replace(/[ ]+/g, ' ').split(' ');
                    var lName = data[lastNameIndex].replace(/[^\w\s]|_/g, function ($1) {
                        return ' ' + $1 + ' ';
                    }).replace(/[ ]+/g, ' ').split(' ');
                    return fnRegex.test(fName[0]) || fnRegex.test(fName[1]) || fnRegex.test(fName[2]) || fnRegex.test(lName[0]) || fnRegex.test(lName[1]) || fnRegex.test(lName[1]);
                }
            );
        }

        $('.bdatepicker').datepicker({
            format: "dd/mm/yyyy"
        });

        var datatables = $('#example').DataTable({
            columnDefs: [
                { targets: 'no-sort', orderable: false }
            ],
            dom: '<"table-filter">B<"toolbar">frtip',
            language: { search: "", searchPlaceholder: "Search" },
            buttons: [
                'copyHtml5',
                'excelHtml5',
                'csvHtml5',
                'pdfHtml5'
            ],
            initComplete: function(){
                $("div.toolbar")
                    .html('<a href="<?=base_url("admin/$active_class/add")?>" class="btn btn-sm btn-default"><i class="fa fa-plus"></i> Add</a> <a href="#" class="btn btn-sm btn-default editBtn"><i class="fa fa-pencil"></i> Edit</a> <a href="#" class="btn btn-sm btn-default delBtn"><i class="fa fa-trash"></i> Delete</a>');
                var filterInp = $("#table-filter");
                if(filterInp.length > 0) {
                    var tableFilter = $("div.table-filter");
                    tableFilter.html(filterInp.html());

                    if($(".table-filter .dpo").length > 0) {
                        $('.table-filter .dpo[data-name="date_from"]').datepicker({
                            format: "dd/mm/yyyy",
                            "onSelect": function (date) {
                                minDateFilter = new Date(date).getTime();
                                datatables.fnDraw();
                            }
                        });
                        $('.table-filter .dpo[data-name="date_to"]').datepicker({
                            format: "dd/mm/yyyy",
                            "onSelect": function (date) {
                                maxDateFilter = new Date(date).getTime();
                                datatables.fnDraw();
                            }
                        });
                    }
                }
            },
            "drawCallback": function () {
                $('.dataTables_paginate .paginate_button').addClass('btn btn-default');
            }
        });
        $(document).ready(function() {

            if($(".table-filter .dpo").length > 0) {
                $(".table-filter .dpo[data-name='date_from']").on("change", function () {
                    minDateFilter = new Date(toDate(this.value)).getTime();
                    datatables.draw();
                });
                $(".table-filter .dpo[data-name='date_to']").on("change", function () {
                    maxDateFilter = new Date(toDate(this.value)).getTime();
                    datatables.draw();
                });
            }
            $('.table-filter input[data-name="age_from"], .table-filter input[data-name="age_to"]').on("keyup change", function () {
                datatables.draw();
            });
            $(".table-filter input[data-name='name']").on("keyup", function () {
                datatables.draw();
            });
            $('.example').dataTable();
            $(".singleSelect:checked").prop("checked", false);
            $(".singleSelect").click(function () {
                var that = $(this);
                var checked = that.is(":checked");
                $("table .singleSelect:checked").prop("checked", false);
                if(checked) {
                    that.prop("checked", true);
                    //console.log(that.data('id'));
                    $("#example").attr("data-selected_id", that.data('id'))
                } else
                    $("#example").attr("data-selected_id", "")
            });

            var filterInputs = $(".table-filter input, .table-filter select");
            filterInputs.each(function (x, y) {
                var name = $(y).data('name');
                //console.log(name)
                if(name != undefined) {
                    $(y).on("change keyup", function () {
                        if ($.inArray(name, ['name', 'date_from', 'date_to','age_from','age_to']) === -1) {
                            var colIndex = $("#example thead").find(".column-"+name).index();
                            if (datatables.column(colIndex).search() !== this.value) {
                                datatables.column(colIndex).search(this.value).draw();
                            }
                        }
                    });
                }
            });

        });

    </script>
<?php } ?>
<!--Date Table-->



<script>
    $(function () {
        $(document.body).on("click",".editBtn",function () {
            var selected = $("#example").attr("data-selected_id");
            if(selected != ""){
                location.href = "<?=site_url();?>admin/<?=@$active_class?>/" + selected + "/edit.php"
            } else
                alert("Please select a row to edit.");
        });

        $(document.body).on("click",".delBtn",function () {
            var selected = $("#example").attr("data-selected_id");
            if(selected != ""){
                location.href = "<?=site_url();?>admin/<?=@$active_class?>/" + selected + "/delete.php"
            } else
                alert("Please select a row to delete.");
        });

        $(document.body).on("click",".replyBtn",function () {
            $(this).text(function (i,text) {
                return text == "Reply" ? "Close" : "Reply";
            });
            $(".replyDiv").toggleClass('hide');
        });

        $(document.body).on("click",".addNote", function () {
            $("#noteDIv").append('<div class="row"> <div class="col-xs-10"> <input type="text" class="form-control" placeholder="Write note here" name="note[]"> </div> <div class="col-xs-2"> <button type="button" class="btn btn-circle btn-success btn-sm addNote"><i class="fa fa-plus"></i></button> <button type="button" class="btn btn-circle btn-danger btn-sm delNote"><i class="fa fa-minus"></i></button> </div> </div>');
        });

        $(document.body).on("click",".addFile", function () {
            $("#attachDiv").append('<div class="attach-main"> <div class="attach-file"> <input type="file" name="attachment[]"> </div> <div class="attach-buttons"> <button type="button" class="btn btn-circle btn-success btn-sm addFile"><i class="fa fa-plus"></i></button> <button type="button" class="btn btn-circle btn-danger btn-sm delFile"><i class="fa fa-minus"></i></button></div></div>');
        });

        $(document.body).on("click",".delNote, .delFile", function () {
            $(this).closest('.attach-main').remove();
        });
    });
</script>

<script type="text/javascript" class="init">

    function setActiveOnlinePackage(id) {
        numid = id.split('_')[1];
        $('#cars_data_list div').removeClass('active');
        $('li').removeClass('active');
        $('#'+id).parent().closest('ul').addClass('active');
        $('#'+id).parent().parent().addClass('car-sel-bx active');

    }

</script>
<!--Slider-->
<?php if(in_array("slider",$css_type)) { ?>
<?php } ?>
<!--Slider-->

<script type="text/javascript">
    $('.partners').bxSlider({
        minSlides: 5,
        maxSlides: 8,
        slideWidth: 240,
        slideMargin: 10,
        infiniteLoop: true,
        auto:true
    });
    $url = "<?php echo site_url(); ?>";
    $lang = $url.split(".fr/");
    if($lang[1] == 'en') {
        $(".liContactUs").css("width","108px");
        $(".liContactUs").css("text-align","center");
        $(".top-links").css("margin-left","0px");
        //  $(".copyright-left").css("font-size","9px");
    }
    else if ($lang[1] == 'fr') {
        $(".liContactUs").css("width","147px");
        $(".liContactUs").css("text-align","center");
        $(".liContactUs a").css("font-size","12px");
        $(".top-links").css("margin-left","-50px");
        //  $(".copyright-left").css("font-size","9px");
    }
    $(".scroll-up > .bx-wrapper").css("max-width","570px");
</script>
</body>
</html>