<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Calls extends MY_Controller
{
	function __construct()
	{
		parent::__construct();

		$this->load->library('form_validation');
		$this->load->helper('url');
		$this->lang->load('auth');
		$this->load->helper('language');
		if (!$this->basic_auth->is_login())
			redirect("admin", 'refresh');
		else
			$this->data['user'] = $this->basic_auth->user();
		$this->load->model('calls_model');
		$this->load->model('notes_model');

		$this->data['configuration'] = get_configuration();
	}


	public function index(){
		$this->data['css_type'] 	= array("form","datatable");
		$this->data['active_class'] = "calls";
		$this->data['gmaps'] 		= false;
		$this->data['title'] 		= $this->lang->line("calls");
		$this->data['title_link'] 	= base_url('admin/calls');
		$this->data['content'] 		= 'admin/calls/index';

		$this->data['data'] = $this->calls_model->getAll();
		$this->_render_page('templates/admin_template', $this->data);
	}

	public function add(){
		$this->data['css_type'] 	= array("form");
		$this->data['active_class'] = "calls";
		$this->data['gmaps'] 	= false;
		$this->data['title'] 	= $this->lang->line("calls");
		$this->data['title_link'] 	= base_url('admin/calls');
		$this->data['subtitle'] = "Add";
		$this->data['content']  = 'admin/calls/add';
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$this->store();
		}

		$this->_render_page('templates/admin_template', $this->data);
	}

	public function store(){
			$error = call_validate();
			if (empty($error)) {
				$this->db->trans_begin();

				$dob = to_unix_date(@$_POST['dob']);
				$id = $this->calls_model->create([
					'civility' 		=> @$_POST['civility'],
					'first_name' 	=> @$_POST['name'],
					'last_name' 	=> @$_POST['prename'],
					'email' 		=> @$_POST['email'],
					'telephone' 	=> @$_POST['num'],
					'subject' 		=> @$_POST['subject'],
					'message' 		=> @$_POST['message'],
					'day' 			=> @$_POST['days'],
					'dob' 			=> @$dob,
					'from_time' 	=> @$_POST['from_time'],
					'to_time' 		=> @$_POST['to_time'],
					'status' 		=> @$_POST['status'],
					'msg_subject' 	=> @$_POST['msg_subject'],
					'ip_address'	=> $this->input->ip_address()
				]);

				$notes = $this->notes_model->createNotesArray($id, 'call');
				if(!empty($notes)) $this->notes_model->bulkInsert($notes);

				$this->session->set_flashdata('alert', [
					'message' => "Successfully Created.",
					'class' => "alert-success",
					'type' => "Success"
				]);
				redirect('admin/calls/'.$id.'/edit');
			} else {
				$this->data['alert'] = [
					'message' => @$error[0],
					'class' => "alert-danger",
					'type' => "Error"
				];
			}
	}

	public function edit($id){

		$this->data['data'] 		= $this->calls_model->get(['id' => $id]);
		if($this->data['data'] != false) {
			$this->data['css_type'] = array("form");
			$this->data['active_class'] = "calls";
			$this->data['gmaps'] = false;
			$this->data['title'] 	= $this->lang->line("calls");
			$this->data['title_link'] = base_url('admin/calls');
			$this->data['subtitle'] = create_timestamp_uid($this->data['data']->created_at,$id);
			$this->data['content']  = 'admin/calls/edit';
			$this->data['notes'] = $this->notes_model->getAll(['type' => 'call','type_id' => $id]);

			if($this->data['data']->unread != 0)
				$this->calls_model->update(['unread' => 0], $id);

			if($this->data['data']->status == "New")
				$this->calls_model->update(['Status' => "Pending"], $id);

			$this->_render_page('templates/admin_template', $this->data);
		} else show_404();
	}

	public function update($id){
		$call = $this->calls_model->get(['id' => $id]);
		if($call != false) {
			//$error = call_validate();
			if (empty($error)) {

				$dob = to_unix_date(@$_POST['dob']);
				$this->calls_model->update([
/*						'civility' 		=> @$_POST['civility'],
						'first_name' 	=> @$_POST['name'],
						'last_name' 	=> @$_POST['prename'],
						'email' 		=> @$_POST['email'],
						'telephone' 	=> @$_POST['num'],
						'subject' 		=> @$_POST['subject'],
						'message' 		=> @$_POST['message'],
						'day' 			=> @$_POST['days'],
						'dob' 			=> @$dob,
						'from_time' 	=> @$_POST['from_time'],
						'to_time' 		=> @$_POST['to_time'],*/
						'status' 		=> @$_POST['status']
				], $id);

				$this->notes_model->delete(['type' => 'call', 'type_id' => $id]);
				$notes = $this->notes_model->createNotesArray($id, 'call');
				if(!empty($notes)) $this->notes_model->bulkInsert($notes);

				$this->session->set_flashdata('alert', [
						'message' => "Successfully Updated.",
						'class' => "alert-success",
						'type' => "Success"
				]);
			} else {
				$this->session->set_flashdata('alert', [
						'message' => @$error[0],
						'class' => "alert-danger",
						'type' => "Error"
				]);
			}
			redirect('admin/calls/'.$id.'/edit');
		} else show_404();
	}

	public function reply($id){
		$call = $this->calls_model->get(['id' => $id]);
		if($call != false) {
			$this->form_validation->set_rules('reply_subject', 'Subject', 'trim|xss_clean|min_length[0]|max_length[200]');
			$this->form_validation->set_rules('reply_message', 'Message', 'trim|xss_clean|min_length[0]|max_length[5000]');
			if ($this->form_validation->run() !== false) {

				$subject = isset($_POST['reply_subject']) ? $_POST['reply_subject'] : '';
				$message = isset($_POST['reply_message']) ? $_POST['reply_message'] : '';
				$check = sendReply($call,$subject,$message);

				if($check['status'] != false) {
					$this->calls_model->update(['last_action' => date('Y-m-d H:i:s')], $id);
					$this->session->set_flashdata('alert', [
						'message' => "Successfully Reply Sent.",
						'class' => "alert-success",
						'type' => "Success"
					]);
				} else
					$this->session->set_flashdata('alert', [
							'message' => $check['message'],
							'class' => "alert-danger",
							'type' => "Danger"
					]);
			} else {
				$validator['messages'] = "";
				$counter = 0;
				foreach ($_POST as $key => $inp) {
					if(form_error($key) != false){
						$this->session->set_flashdata('alert', [
								'message' => form_error($key,"<span>","</span>"),
								'class' => "alert-danger",
								'type' => "Danger"
						]);
						break;
					}
				}
			}

			redirect('admin/calls/'.$id.'/edit');
		} else show_404();
	}

	public function delete($id){
		$this->calls_model->delete($id);
		$this->session->set_flashdata('alert', [
				'message' => "Successfully deleted.",
				'class' => "alert-success",
				'type' => "Success"
		]);
		redirect('admin/calls');
	}
}