<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Dashboard extends MY_Controller

{
	function __construct()
	{
		parent::__construct();

		$this->load->library('form_validation');
		$this->load->helper('url');
		$this->lang->load('auth');
		$this->load->helper('language');
		if (!$this->basic_auth->is_login())
			redirect("admin", 'refresh');
		else
			$this->data['user'] = $this->basic_auth->user();

		$this->data['configuration'] = get_configuration();
	}


	public function index(){
		$this->data['css_type'] 	= array("form","datatable");
		$this->data['active_class'] = "dashboard";
		$this->data['gmaps'] 		= false;
		$this->data['title'] 		= $this->lang->line('dashboard');
		$this->data['content'] 		= 'admin/dashboard';

		$this->load->model('calls_model');
		$this->load->model('request_model');
		$this->load->model('jobs_model');


		$data = [];
		$data['request'] = $this->request_model->getAll();
		$data['jobs'] 	 = $this->jobs_model->getAll();
		$data['calls']   = $this->calls_model->getAll();

		foreach($data as $key => $d){
			if($d != false){
				foreach($d as $i){
					if(!empty($i->status))
						$this->data[$key][strtolower($i->status)] = isset($this->data[$key][strtolower($i->status)]) ? $this->data[$key][strtolower($i->status)] + 1 : 1;
				}
			}
		}

		$this->_render_page('templates/admin_template', $this->data);
	}


	public function logout(){
		$this->basic_auth->logout();
		redirect("admin", 'refresh');
	}
}