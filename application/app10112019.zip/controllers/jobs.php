<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Jobs extends MY_Controller
{
	function __construct()
	{
		parent::__construct();

		$this->load->library('form_validation');
		$this->load->helper('url');
		$this->lang->load('auth');
		$this->load->helper('language');
		if (!$this->basic_auth->is_login())
			redirect("admin", 'refresh');
		else
			$this->data['user'] = $this->basic_auth->user();
		$this->load->model('jobs_model');
		$this->load->model('notes_model');

		$this->data['configuration'] = get_configuration();
	}

	public function index(){
		$this->data['css_type'] 	= array("form","datatable");
		$this->data['active_class'] = "jobs";
		$this->data['gmaps'] 		= false;
		$this->data['title'] 		= $this->lang->line("jobs");
		$this->data['title_link'] 	= base_url('admin/jobs');
		$this->data['content'] 		= 'admin/jobs/index';

		$this->data['data'] = $this->jobs_model->getAll();
		$this->_render_page('templates/admin_template', $this->data);
	}

	public function add(){
		$this->data['css_type'] 	= array("form");
		$this->data['active_class'] = "jobs";
		$this->data['gmaps'] 	= false;
		$this->data['title'] 	= $this->lang->line("jobs");
		$this->data['title_link'] 	= base_url('admin/jobs');
		$this->data['subtitle'] = "Add";
		$this->data['content']  = 'admin/jobs/add';
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$this->store();
		}

		$this->_render_page('templates/admin_template', $this->data);
	}


	public function store(){
			$error = job_validate(true);
			$CV = $Letter = false;

			createJobFilesPath();
			$this->uploadJobFiles($CV, $Letter, $error);

			if (empty($error)) {
				$evaluation = [
					'communication' => $this->input->post('communication'),
					'presentation' 	=> $this->input->post('presentation'),
					'driving' 		=> $this->input->post('driving'),
					'look' 			=> $this->input->post('look'),
					'experience' 	=> $this->input->post('experience'),
				];

				$dob = to_unix_date(@$_POST['dob']);
				$id = $this->jobs_model->create([
					'civility' 		=> @$_POST['civility'],
					'first_name' 	=> @$_POST['name'],
					'last_name' 	=> @$_POST['prename'],
					'email' 		=> @$_POST['email'],
					'telephone' 	=> @$_POST['tel'],
					'postal_code' 	=> @$_POST['postal_code'],
					'dob' 			=> $dob,
					'age' 			=> calculateAge($dob),
					'status' 		=> @$_POST['status'],
					'msg_subject' 	=> @$_POST['msg_subject'],
					'cv' 			=> $CV != false ? json_encode($CV) : '',
					'letter' 		=> $Letter != false ? json_encode($Letter) : '',
					'evaluation' 	=> json_encode($evaluation),
					'ip_address'	=> $this->input->ip_address(),
				]);

				$notes = $this->notes_model->createNotesArray($id, 'job');
				if(!empty($notes)) $this->notes_model->bulkInsert($notes);

				$this->session->set_flashdata('alert', [
					'message' => "Successfully Created.",
					'class' => "alert-success",
					'type' => "Success"
				]);
				redirect('admin/jobs/'.$id.'/edit');
			} else {
				$this->data['alert'] = [
					'message' => @$error[0],
					'class' => "alert-danger",
					'type' => "Error"
				];
			}
	}

	public function edit($id){

		$this->data['data'] 		= $this->jobs_model->get(['id' => $id]);
		if($this->data['data'] != false) {
			$this->data['css_type'] = array("form");
			$this->data['active_class'] = "jobs";
			$this->data['gmaps'] 	= false;
			$this->data['title'] 	= $this->lang->line("jobs");
			$this->data['title_link'] 	= base_url('admin/jobs');
			$this->data['subtitle'] = create_timestamp_uid($this->data['data']->created_at,$id);
			$this->data['content']  = 'admin/jobs/edit';
			$this->data['evaluation']  = json_decode($this->data['data']->evaluation, true);

			if($this->data['data']->unread != 0)
				$this->jobs_model->update(['unread' => 0], $id);

			if($this->data['data']->status == "New")
				$this->jobs_model->update(['Status' => "Pending"], $id);

			$this->data['notes'] = $this->notes_model->getAll(['type' => 'job','type_id' => $id]);

			$this->_render_page('templates/admin_template', $this->data);
		} else show_404();
	}

	public function update($id){
		$job = $this->jobs_model->get(['id' => $id]);
		if($job != false) {
//			$error = job_validate(false);
//			$CV = $Letter = false;

//			createJobFilesPath();
//			$this->uploadJobFiles($CV, $Letter, $error);

			if (empty($error)) {

				$evaluation = [
					'communication' => $this->input->post('communication'),
					'presentation' 	=> $this->input->post('presentation'),
					'driving' 		=> $this->input->post('driving'),
					'look' 			=> $this->input->post('look'),
					'experience' 	=> $this->input->post('experience'),
				];

//				$dob = to_unix_date(@$_POST['dob']);
				$this->jobs_model->update([
/*						'civility' 		=> @$_POST['civility'],
						'first_name' 	=> @$_POST['name'],
						'last_name' 	=> @$_POST['prename'],
						'email' 		=> @$_POST['email'],
						'telephone' 	=> @$_POST['tel'],
						'postal_code' 	=> @$_POST['postal_code'],
						'dob' 			=> $dob,
						'age' 			=> calculateAge($dob),*/
						'status' 		=> @$_POST['status'],
						'evaluation' 	=> json_encode($evaluation),
/*						'cv' 			=> $CV != false ? json_encode($CV) : $job->cv,
						'letter' 		=> $Letter != false ? json_encode($Letter) : $job->letter,*/
				], $id);

				$this->notes_model->delete(['type' => 'job', 'type_id' => $id]);
				$notes = $this->notes_model->createNotesArray($id, 'job');
				if(!empty($notes)) $this->notes_model->bulkInsert($notes);

				$this->session->set_flashdata('alert', [
						'message' => "Successfully Updated.",
						'class' => "alert-success",
						'type' => "Success"
				]);
			} else {

				$this->session->set_flashdata('alert', [
						'message' => @$error[0],
						'class' => "alert-danger",
						'type' => "Error"
				]);
			}

			redirect('admin/jobs/'.$id.'/edit');
		} else show_404();
	}

	public function reply($id){
		$call = $this->jobs_model->get(['id' => $id]);
		if($call != false) {
			$this->form_validation->set_rules('reply_subject', 'Subject', 'trim|xss_clean|min_length[0]|max_length[200]');
			$this->form_validation->set_rules('reply_message', 'Message', 'trim|xss_clean|min_length[0]|max_length[5000]');
			if ($this->form_validation->run() !== false) {

				$subject = isset($_POST['reply_subject']) ? $_POST['reply_subject'] : '';
				$message = isset($_POST['reply_message']) ? $_POST['reply_message'] : '';
				$check = sendReply($call,$subject,$message, "job");

				if($check['status'] != false) {
					$this->jobs_model->update(['last_action' => date('Y-m-d H:i:s')], $id);
					$this->session->set_flashdata('alert', [
						'message' => "Successfully Reply Sent.",
						'class' => "alert-success",
						'type' => "Success"
					]);
				} else
					$this->session->set_flashdata('alert', [
							'message' => $check['message'],
							'class' => "alert-danger",
							'type' => "Danger"
					]);
			} else {
				$validator['messages'] = "";
				foreach ($_POST as $key => $inp) {
					if(form_error($key) != false){
						$this->session->set_flashdata('alert', [
								'message' => form_error($key,"<span>","</span>"),
								'class' => "alert-danger",
								'type' => "Danger"
						]);
						break;
					}
				}
			}

			redirect('admin/jobs/'.$id.'/edit');
		} else show_404();
	}

	public function delete($id){
		$this->jobs_model->delete($id);

		$this->session->set_flashdata('alert', [
				'message' => "Successfully deleted.",
				'class' => "alert-success",
				'type' => "Success"
		]);
		redirect('admin/jobs');
	}

	public function uploadJobFiles(&$CV, &$Letter, &$error){

		$this->load->library('upload');
		if(isset($_FILES['cv']['name']) && !empty($_FILES['cv']['name'])){
			$config['upload_path'] 				= './uploads/jobs/cv/'. date('Y-m-d') . '/';
			$config['allowed_types'] 			= 'doc|docx|pdf';
			$config['max_size'] 				= '10240';
			$config['file_name'] 				= str_replace(' ', '_', $_FILES['cv']['name']);

			$this->upload->initialize($config);
			if (!$this->upload->do_upload('cv')) {
				$error[] = $this->upload->display_errors();
			} else {
				$CV =  $this->upload->data();
				$CV['upload_path'] = 'uploads/jobs/cv/'. date('Y-m-d') . '/' . $CV['file_name'];
			}
		}

		if(isset($_FILES['letter']['name']) && !empty($_FILES['letter']['name'])){
			$letterConfig['upload_path'] 	= './uploads/jobs/letter/'. date('Y-m-d') . '/';
			$letterConfig['allowed_types'] 	= 'doc|docx|pdf';
			$letterConfig['max_size'] 		= '10240';
			$letterConfig['file_name'] 		= str_replace('_', '', $_FILES['letter']['name']);
			$this->upload->initialize($letterConfig);
			if (!$this->upload->do_upload('letter')) {
				$error[] = $this->upload->display_errors();
			} else {
				$Letter =  $this->upload->data();
				$Letter['upload_path'] = 'uploads/jobs/letter/'. date('Y-m-d') . '/' . $Letter['file_name'];
			}
		}
	}
}