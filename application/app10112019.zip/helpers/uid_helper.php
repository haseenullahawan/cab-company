<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

if ( ! function_exists('create_uid'))
{
    function create_uid($start = "", $id = 0, $length = 5)
    {
        return $start . str_pad($id, $length, '0', STR_PAD_LEFT);
    }
}
if ( ! function_exists('create_timestamp_uid'))
{
    function create_timestamp_uid($timestamp = "", $id = 0, $length = 5)
    {
        return create_uid(date("dmY",strtotime($timestamp)),$id,$length);
    }
}