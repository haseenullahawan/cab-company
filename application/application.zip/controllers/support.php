<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Support extends MY_Controller

{
	function __construct()
	{
		parent::__construct();

		$this->load->library('form_validation');
		$this->load->helper('url');
		$this->lang->load('auth');
		$this->lang->load('general');
		$this->load->helper('language');
		if (!$this->basic_auth->is_login())
			redirect("admin", 'refresh');
		else
			$this->data['user'] = $this->basic_auth->user();
		$this->load->model('request_model');
		$this->load->model('jobs_model');
		$this->load->model('support_model');
		$this->load->model('calls_model');
		$this->load->model('smtp_model');
        $this->load->model('notifications_model');
		$this->data['configuration'] = get_configuration();
	}
	
	public function GetSupportAttachments($support_id){
		return $this->support_model->GetSupportAttachments($support_id);
	}

	public function index(){
		$this->data['css_type'] 	= array("form","datatable");
		$this->data['active_class'] = "support";
		$this->data['gmaps'] 		= false;
		$this->data['title'] 		= $this->lang->line("support");
		$this->data['content'] 		= 'admin/support/index';
		$this->data['obj'] 		    = $this;

		$this->data['data'] = $this->support_model->getAll();
		$this->_render_page('templates/admin_template', $this->data);
	}

	public function add(){
		$this->data['css_type'] 	= array("form");
		$this->data['active_class'] = "support";
		$this->data['gmaps'] 	= false;
		$this->data['title'] 	= $this->lang->line("support");
		$this->data['title_link'] 	= site_url('admin/support');
		$this->data['subtitle'] = "Add";
		$this->data['content']  = 'admin/support/add';
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$this->store();
		}
		$this->_render_page('templates/admin_template', $this->data);
	}

	public function store(){
			//$error = support_validate();
			if (empty($error)) {
				$id = $this->support_model->create([
					'p_title' 		=> @$_POST['civility'],
					'fname' 		=> @$_POST['name'],
					'lname' 		=> @$_POST['prename'],
					'email' 		=> @$_POST['email'],
					'company' 		=> @$_POST['company_name'],
					'phone' 		=> @$_POST['tel'],
					'mobile' 		=> @$_POST['mobile'],
					'message' 		=> @$_POST['message'],
					'department' 	=> @$_POST['department'],
					'priority' 		=> @$_POST['priority'],
					'status' 		=> @$_POST['status'],
					'subject' 		=> @$_POST['msg_subject'],
					'ip_address'	=> $this->input->ip_address()
				]);
				
				$filename = "";
				if($_FILES['attachments']['name'][0]!=''){
					$this->load->library('upload');
					$files = $_FILES;
					$aantal = count($_FILES['attachments']['name']);
					for($i=0; $i<$aantal; $i++)
					{
						$_FILES['attachments']['name']= $files['attachments']['name'][$i];
						$_FILES['attachments']['type']= $files['attachments']['type'][$i];
						$_FILES['attachments']['tmp_name']= $files['attachments']['tmp_name'][$i];
						$_FILES['attachments']['error']= $files['attachments']['error'][$i];
						$_FILES['attachments']['size']= $files['attachments']['size'][$i];    

						$tmpFilePath = $_FILES['attachments']['tmp_name'];
						
						$filename = time() . '_' .$_FILES['attachments']['name'];
						
						//Make sure we have a file path
						if ($tmpFilePath != ""){
							//Setup our new file path
							$newFilePath = "./uploads/contact_files/" . $filename;

							//Upload the file into the temp dir
							if(move_uploaded_file($tmpFilePath, $newFilePath)) {
								$inputdata1 = array(
												'support_id' => $id,
												'filename' => $filename,
											);
								$this->support_model->insert_operation($inputdata1, 'support_attachments');
							}
						}else{
							$filename = "";
						}
					
					}
				}

				$this->session->set_flashdata('alert', [
					'message' => "Successfully Created.",
					'class' => "alert-success",
					'type' => "Success"
				]);
				redirect('admin/support/'.$id.'/edit');
			} else {
				$this->data['alert'] = [
					'message' => @$error[0],
					'class' => "alert-danger",
					'type' => "Error"
				];
			}
	}

	public function edit($id){

		$this->data['data'] 		= $this->support_model->get(['id' => $id]);
		if($this->data['data'] != false) {
			$this->data['css_type'] = array("form");
			$this->data['active_class'] = "support";
			$this->data['gmaps'] = false;
			$this->data['title'] 	= $this->lang->line("support");
			$this->data['title_link'] 	= site_url('admin/support');
			$this->data['subtitle'] = create_timestamp_uid($this->data['data']->created_on,$id);
			$this->data['content']  = 'admin/support/edit';
			$this->load->model('quick_replies_model');
			$this->data['quick_replies']  = $this->quick_replies_model->getAll(array('delete_bit' => 0, 'status' => 1, 'module' => 4));
			$this->data['obj'] 		    = $this;
			if($this->data['data']->unread != 0)
				$this->support_model->update(['unread' => 0], $id);
			
			$this->_render_page('templates/admin_template', $this->data);
		} else show_404();
	}

	public function update($id){
		$support = $this->support_model->get(['id' => $id]);
		if($support != false) {
			//$error = support_validate();
			if (empty($error)) {
                $check = 1;
				if(@$_POST['status'] == "New"){
					$check = 1;
				}else if(@$_POST['status'] == "Pending"){
					$check = 2;
				}else if(@$_POST['status'] == "Replied"){
					$check = 3;
				}else{
					$check = 4;
				}
				$notifications = $this->notifications_model->get(array('status'=>$check, 'department'=>5, 'notification_status'=>1));
				if($notifications != null && !empty($notifications)){
					$MAIL = $this->smtp_model->get(array('id' => 1));
					$check = supportSendReply($support,$notifications->subject,$notifications->message,"",$MAIL,array(@$_POST['status']));
				}
				$this->support_model->update([
/*						'civility' 		=> @$_POST['civility'],
						'first_name' 	=> @$_POST['name'],
						'last_name' 	=> @$_POST['prename'],
						'email' 		=> @$_POST['email'],
						'telephone' 	=> @$_POST['tel'],
						'message' 		=> @$_POST['message'],*/
						'status' 		=> @$_POST['status'],
				], $id);

				$this->session->set_flashdata('alert', [
						'message' => "Successfully Updated.",
						'class' => "alert-success",
						'type' => "Success"
				]);
			} else {

				$this->session->set_flashdata('alert', [
						'message' => @$error[0],
						'class' => "alert-danger",
						'type' => "Error"
				]);
			}
			redirect('admin/support/'.$id.'/edit');
		} else show_404();
	}
	
	public function getQuickReply($id){
		$quick = $this->support_model->getQuickReply($id);
		
		echo $quick->message_sentence;
	}


	public function reply($id){
		$support = $this->support_model->get(['id' => $id]);
		if($support != false) {
			$this->form_validation->set_rules('reply_subject', 'Subject', 'trim|xss_clean|min_length[0]|max_length[200]');
			if($_POST['quick_replies'] == ''){
				$this->form_validation->set_rules('reply_message', 'Message', 'trim|xss_clean|min_length[0]|max_length[5000]');
			}
			
			if ($this->form_validation->run() !== false) {

				$subject = isset($_POST['reply_subject']) ? $_POST['reply_subject'] : '';
				$message = isset($_POST['reply_message']) ? $_POST['reply_message'] : '';
				
				if($_POST['quick_replies'] != ''){
					$quick = $this->support_model->getQuickReply($_POST['quick_replies']);
		
					$message = $quick->message_sentence;
				}
				
				
				$MAIL = $this->smtp_model->get(array('id' => 1));
				$check = supportSendReply($support,$subject,$message,"",$MAIL);

				if($check['status'] != false) {
					$this->support_model->update(['modified_on' => date('Y-m-d H:i:s')], $id);
					$this->session->set_flashdata('alert', [
						'message' => "Successfully Reply Sent.",
						'class' => "alert-success",
						'type' => "Success"
					]);
				} else
					$this->session->set_flashdata('alert', [
							'message' => $check['message'],
							'class' => "alert-danger",
							'type' => "Danger"
					]);
			} else {
				$validator['messages'] = "";
				foreach ($_POST as $key => $inp) {
					if(form_error($key) != false){
						$this->session->set_flashdata('alert', [
								'message' => form_error($key,"<span>","</span>"),
								'class' => "alert-danger",
								'type' => "Danger"
						]);
						break;
					}
				}
			}

			redirect('admin/support/'.$id.'/edit');
		} else show_404();
	}

	public function delete($id){
		$this->support_model->delete($id);
		$this->session->set_flashdata('alert', [
				'message' => "Successfully deleted.",
				'class' => "alert-success",
				'type' => "Success"
		]);
		redirect('admin/support');
	}
}