<?php
defined('BASEPATH') OR exit('No direct script access allowed');
include APPPATH . 'controllers/vehicle_settings.php';

class Reports extends Vehicle_Settings

{
	/*
	| -----------------------------------------------------
	| PRODUCT NAME: 	DIGI VEHICLE BOOKING SYSTEM (DVBS)
	| -----------------------------------------------------
	| AUTHOR:			DIGITAL VIDHYA TEAM
	| -----------------------------------------------------
	| EMAIL:			digitalvidhya4u@gmail.com
	| -----------------------------------------------------
	| COPYRIGHTS:		RESERVED BY DIGITAL VIDHYA
	| -----------------------------------------------------
	| WEBSITE:			http://digitalvidhya.com
	|                   http://codecanyon.net/user/digitalvidhya
	| -----------------------------------------------------
	|
	| MODULE: 			Reports
	| -----------------------------------------------------
	| This is Reports module controller file.
	| -----------------------------------------------------
	*/
	function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		redirect('/');
	}

	/****** OVERALL VEHICLES ******/
	function overallVehicles()
	{
		$vehicleSettingsContrlrRef = new Vehicle_Settings;
		$vehicleSettingsContrlrRef->vehicles('reports');
	}

	function payments()
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) redirect('auth', 'refresh');
		$records = $this->base_model->run_query('select b.*,v.name as vehicle_name,v.model from ' . $this->db->dbprefix("bookings") . ' b, ' . $this->db->dbprefix("vehicle") . ' v where v.id=b.vehicle_selected and (b.payment_type="paypal" and b.payment_received=1 and  b.is_conformed!="cancelled") OR (b.payment_type="cash" and b.is_conformed="confirm") GROUP BY b.id ORDER BY b.bookdate DESC');
		$this->data['records'] 				= $records;
		$this->data['active_menu'] 			= 'reports';
		$this->data['gmaps'] 				= "false";
		$this->data['css_type'] 			= array("form","datatable");
		$this->data['title'] 				= 'Payments';
		$this->data['active_class'] 		= "report";
		$this->data['sub_title'] 			= 'Reports';
		$this->data['content'] 				= 'admin/reports/payment_reports';
		$this->_render_page('templates/admin_template', $this->data);
	}

	
}