<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');



class Basic_auth
{

	public function __construct(){

		$this->load->library('email');
		$this->load->helper('url');
		$this->load->library('session');
		$this->load->model('user_model');
	}

	public function __get($var){

		return get_instance()->$var;
	}

	public function generateRememberMeToken($user){
		return md5($user->password . time());
	}

	public function setRememberMeToken($user){

		$token = $this->generateRememberMeToken($user);
		$this->user_model->update(['remember_code' => $token], $user->id);
		$cookie = array(
			'name'   => 'remember_me_token',
			'value'  => $token,
			'expire' => '1209600',  // Two weeks
			'path'   => '/'
		);

		set_cookie($cookie);
	}

	public function login($username, $password, $remember){
		$user = $this->user_model->login($username,$password, "email");

		if ($user != false && $user->active == 1) {
			$this->session->set_userdata("user", $user);

			if($remember != false){
				$this->setRememberMeToken($user);
			}
			sleep(1);
			return $user;
		}

		return false;
	}

	public function is_login(){
		$check = $this->session->userdata("user") !== false;
		if($check == false && isset($_COOKIE['remember_me_token']) && !empty($_COOKIE['remember_me_token'])){
			$user = $this->user_model->get(['remember_code' => $_COOKIE['remember_me_token']]);
			if ($user != false && $user->active == 1) {
				$this->session->set_userdata("user", $user);
				$this->setRememberMeToken($user);
				$check = true;
			}
		}
		return $check;
	}

	public function user(){
		return $this->session->userdata("user");
	}

	public function logout(){
		if($this->is_login()) {
			$user = $this->session->userdata("user");
			$this->user_model->update(['remember_code' => ''], $user->id);
			return $this->session->unset_userdata("user");
		}

		return true;
	}

	public function resetPasswordKey($user, $counter = 3){

		$ifExist = $this->user_model->getResetPassword(['user_id' => $user->id]);
		if($ifExist != false){
			return $ifExist->verification_code;
		} else {
			$key = md5($user->id . "-" . time());
			$insert = [
				'user_id' => $user->id,
				'verification_code' => $key,
				'counter' => $counter
			];
			$this->user_model->addResetPassword($insert);
			return $key;
		}
	}

	public function verifyAccount($key){
		return $this->user_model->verifyAccount($key);
	}

}