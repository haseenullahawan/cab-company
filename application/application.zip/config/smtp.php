<?php
/**
 * Created by PhpStorm.
 * User: lenovo
 * Date: 20/10/2019
 * Time: 10:55 AM
 */

$config['host']     = "";
$config['username'] = "";
$config['password'] = "";
$config['port']     = "";
$config['ssl']      = 0;