<link href="<?php echo base_url(); ?>assets/system_design/css/login.css" rel="stylesheet">
</header>
  
<div class="container body-border">
    <div class="breadcrumb">
        <div class="row">
            <aside class="nav-links">
                <ul>
                    <li> <a href="<?php echo site_url(); ?>/"> <?php echo $this->lang->line('home_page'); ?>  </a> </li>
                    <li class="active"><a href="javascript:void(0)">&nbsp;<?php if (isset($sub_heading)) echo $sub_heading; ?> </a></li>
                </ul>
            </aside>
        </div>
    </div>
    <?php if ($journey_details != "") : ?>
        <div class="bcp" style="margin-top:0px;">
            <ul class='nav nav-wizard'>
                <li><span class="steps">1</span><a style="color:#fff !important"><?php echo $this->lang->line('journey_details'); ?></a></li>
                <li class='active'><span class="steps">2</span><a style="color:#fff !important"><?php echo $this->lang->line('identification'); ?></a></li>
                <li><span class="steps">3</span><a><?php echo $this->lang->line('quote'); ?></a></li>
                <li><span class="steps">4</span><a><?php echo $this->lang->line('payment_details'); ?></a></li>
            </ul>
        </div>
    <?php endif; ?>

     <div class="row">
            <div class="col-md-6"> 
                <?php echo form_open('driverlogin', array("id"=>"loginform"));?>
                <div class="row">
                    <div class="col-md-6 col-md-offset-2">
                        
                        <div class="form-group">
                            <label for="username">Username</label>
                            <input class="form-control" type="text" id="username" name="username" autofocus>
                        </div>    
                        <div class="form-group">    
                            <label for="password">Password <a href="#">lost password?</a></label>
                            <input class="form-control" type="password" id="password" name="password" >
                        </div>
                         
                        <div class="form-group">
                            <input type="checkbox" id="remember" name="remember" style="float:left;margin-right: 10px;"> <label for="remember" class="checkbox" style="float:left;top:-8px;position:relative;">remember me</label>
                        </div>
                        <div class="clearfix"></div>  
    	            </div>
               </div> 
                <div class="row">
                    <div class="col-md-6 col-md-offset-2"> 
                        <input type="submit" class="button green_button" value="Register" style="margin-top: 30px;" /> 
                    </div>
                </div>
                <?php echo form_close();?>   
            </div>
        
        <div class="col-md-6 benefits" style="padding-left: 60px;">
            <div class="titleBox">
                <h4>Benefits</h4>
                <h6>Why Choose Handi Express for your transfers ?</h6>
            </div>
            <div class="infoBox">
                <div class="col-md-2 wallet"><i class="fa fa-money"></i></div>
                <div class="col-md-10">
                    <div class="wallet">
                        <h5>Value for Money</h5>
                        <h6>Quality Journeys at discount prices</h6>
                    </div>
                </div>
            </div>
            <div class="infoBox">
                <div class="col-md-2 customer-service"><i class="fa fa-headphones"></i></div>
                <div class="col-md-10">
                    <div class="wallet">
                        <h5>Customer Service</h5>
                        <h6>Quality Client Service to assist you by phone, by email or by live chat support.</h6>
                    </div>
                </div>
            </div>
            <div class="infoBox">
                <div class="col-md-2 easy-use"><i class="fa fa-leaf"></i></div>
                <div class="col-md-10">
                    <div class="wallet">
                        <h5>Ease of Use</h5>
                        <h6>4 steps only easy booking, client area to follow your bookings online</h6>
                    </div>
                </div>
            </div>
        </div>  
    </div>
</div> 
<script type="text/javascript">$(document).ready(function () {
        $.colorbox({inline: true, href: ".ajax"});

    });
</script> 
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="<?php echo base_url(); ?>assets/system_design/scripts/bootstrap.min.js"></script>
</body>
</html>