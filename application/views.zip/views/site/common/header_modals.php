<style>
.alert alert-success{
    word-break: break-word !important;
}
</style>
<?php 
$data = $this->base_model->run_query("SELECT * FROM ".$this->db->dbprefix('popups_settings')." where id = 1")[0];
?>
<?php if($data->status1 == 1){ ?>
<div class="<?php if($data->position1 == 1){echo "floating-form-2 ";}else{echo "floating-form ";} ?> <?=$data->auto_open1 == 1 ? "visiable" : ""?>"  id="<?php if($data->position1 == 1){echo "contact_form_2";}else if($data->position1 == 2){echo "jobs_form";}else{echo "contact_form";} ?>">
    <div class="<?php if($data->position1 == 1){echo "contact-opener-2";}else if($data->position1 == 2){echo "contact-opener-3";}else{echo "contact-opener";} ?>"><?php echo $data->name1?></div>
    <div id="contact_results"></div>
    <div id="contact_body">
        <a href="javascript:;" class="close-btn-2"><i class="fa fa-times-circle-o"></i></a>
        <?php echo form_open_multipart('auth/callMe', ['id' => 'the-contact-form-2', 'class' => 'form']); ?>
        <input type="hidden" name="success_message" value="<?=strip_tags($data->success_message1)?>">
        <h4 style="text-align: center; margin: 0 0 8px">DEMANDE DE RAPPEL <?php // $data->name1?></h4>
        <div class="row">
            <div class="col-xs-3 form-group" style="padding:0 10px">
                <select class="form-control" name="civility" required>
                    <?php foreach(config_model::$civility as $key => $civil):?>
                        <option value="<?=$civil?>"><?=$civil?></option>
                    <?php endforeach;?>
                </select>
            </div>
            <div class=" form-group col-xs-4">
                <input type="text" maxlength="100" class="form-control" required name="name" placeholder="Nom*">
            </div>

            <div class="form-group col-xs-4">
                <input type="text" maxlength="100" class="form-control" required name="prename" placeholder="Prenom*">
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <div class=" form-group">
                    <input id="enterprise" maxlength="50" type="text" class="form-control" name="company" placeholder="Entreprise ou Organisme (Optionnel)">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <div class="form-group">
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-phone"></i></span>
                        <input id="num2" maxlength="50" type="text" class="form-control" required name="num" placeholder="Telephone*">
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <div class=" form-group">
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                        <input id="phone-email" maxlength="100" type="email" class="form-control" required name="email" placeholder="Votre email*">
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12 form-group" style="padding:0 10px">
                <select class="form-control" name="subject" required>
                    <option value="">Objet de l'appel*</option>
                    <?php foreach(config_model::$call_subjects as $key => $subject):?>
                        <option value="<?=$subject?>"><?=$subject?></option>
                    <?php endforeach;?>
                </select>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-4 form-group" style="padding:0 0 0 10px; width: 42% !important;">
                <select class="form-control" name="days" required>
                    <option value="">Jours de Rappel*</option>
                    <?php foreach(config_model::$call_days as $key => $day):?>
                        <option value="<?=$day?>"><?=$day?></option>
                    <?php endforeach;?>
                </select>
            </div>
            <div class="col-xs-4 form-group" style="padding:0 4px; width: 30%">
                <div class="input-group">
                    <span class="input-group-addon normal-addon" style="border: 0; background: #f2f2f2; padding: 6px">DE</span>
                    <select class="form-control" name="from_time" style="width: 38px !important;" required>
                        <?php for($i = 0; $i <= 24; $i++):
                            $time = $i > 9 ? $i : "0".$i; ?>
                            <option value="<?=$time?>"><?=$time?></option>
                        <?php endfor;?>
                    </select>
                    <span class="input-group-addon normal-addon" style="border: 0; background: #f2f2f2; padding: 6px 0">H</span>
                </div>
            </div>
            <div class="col-xs-4 form-group" style="padding:0 4px 0 0; width: 26%">
                <div class="input-group">
                    <span class="input-group-addon normal-addon" style="border: 0; background: #f2f2f2; padding: 6px">A</span>
                    <select class="form-control" name="to_time" style="width: 38px !important;" required>
                        <?php for($i = 0; $i <= 24; $i++):
                            $time = $i > 9 ? $i : "0".$i; ?>
                            <option value="<?=$time?>"><?=$time?></option>
                        <?php endfor;?>
                    </select>
                    <span class="input-group-addon normal-addon" style="border: 0; background: #f2f2f2; padding: 6px 0">H</span>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <div class=" form-group">
                    <textarea rows="3" maxlength="3000" class="form-control" name="message" placeholder="Merci de nous communiquer le motif de votre appel"></textarea>
                </div>
            </div>
        </div>
        <!--<div class="row">
            <div class="col-xs-12">
                <div class="form-group">
                    <input type="text" class="bdatepicker" name="dob" placeholder="Date de naissance">
                </div>
            </div>
        </div>-->
        <div class="row">
            <div class="col-xs-12" style="text-align: center">
                <button class="btn-successs" type="submit">Rappelez moi</button>
            </div>
        </div>
        <?=form_close();?>
    </div>
</div>
<!-- / End Call Back Form -->
<?php } ?>

<?php if($data->status2 == 1){ ?>
<!-- Jobs Slide Form -->
<div class="<?php if($data->position2 == 1){echo "floating-form-2 ";}else{echo "floating-form ";} ?> <?=$data->auto_open2 == 1 ? "visiable" : ""?>"  id="<?php if($data->position2 == 1){echo "contact_form_2";}else if($data->position2 == 2){echo "jobs_form";}else{echo "contact_form";} ?>">
    <div class="<?php if($data->position2 == 1){echo "contact-opener-2";}else if($data->position2 == 2){echo "contact-opener-3";}else{echo "contact-opener";} ?>"><?=$data->name2?></div>
    <div id="contact_results"></div>
    <div id="contact_body">
        <a href="javascript:;" class="close-btn-3 closee-btn"><i class="fa fa-times-circle-o"></i></a>
        <?php echo form_open_multipart('auth/submitJobForm', ['id' => 'the-job-form', 'class' => 'form']); ?>
        <input type="hidden" name="success_message" value="<?=strip_tags($data->success_message2)?>">
        <div class="row">
            <div class="col-xs-3 form-group" style="padding:0 10px">
                <select class="form-control" name="civility" required>
                    <?php foreach(config_model::$civility as $key => $civil):?>
                        <option value="<?=$civil?>"><?=$civil?></option>
                    <?php endforeach;?>
                </select>
            </div>
            <div class=" form-group col-xs-4">
                <input type="text" maxlength="100" class="form-control" required name="name" placeholder="Nom*">
            </div>

            <div class="form-group col-xs-4">
                <input type="text" maxlength="100" class="form-control" required name="prename" placeholder="Prenom*">
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <div class=" form-group">
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-phone"></i></span>
                        <input id="tel" maxlength="50" type="text" class="form-control" required name="tel" placeholder="Telephone*">
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <div class=" form-group">
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                        <input id="email" maxlength="100" type="email" class="form-control" required name="email" placeholder="Email*">
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-6">
                <div class="form-group">
                    <input type="text" class="bdatepicker" name="dob" required placeholder="Date de naissance">
                </div>
            </div>
            <div class="col-xs-6">
                <div class="form-group">
                    <input type="text" maxlength="20" class="form-control" required name="postal_code" placeholder="Code postal*">
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-xs-12 form-group">
                <select class="form-control" name="offer" required>
                    <option value="">Sélectionnez l'Offre d'emploi</option>
                    <?php foreach(config_model::$job_offers as $key => $offer):?>
                        <option value="<?=$offer?>"><?=$offer?></option>
                    <?php endforeach;?>
                </select>
            </div>
        </div>
        <div class="row">
            <div class="form-group col-xs-12">
                <label>CV*</label>
                <input type="file" required name="cv" accept=".pdf, .doc, .docx">
            </div>
            <div class="form-group col-xs-12">
                <label>Lettre de Motivation</label>
                <input type="file" name="letter" accept=".pdf, .doc, .docx">
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12" style="text-align: center">
                <button class="btn-successs" type="submit">Postuler</button>
            </div>
        </div>
        <?=form_close();?>
    </div>
</div>
<?php } ?>

<?php if($data->status3 == 1){ ?>
<!-- Contact Slide Form -->
<div class="<?php if($data->position3 == 1){echo "floating-form-2 ";}else{echo "floating-form ";} ?> <?=$data->auto_open3 == 1 ? "visiable" : ""?>" id="<?php if($data->position3 == 1){echo "contact_form_2";}else if($data->position3 == 2){echo "jobs_form";}else{echo "contact_form";} ?>">
    <div class="<?php if($data->position3 == 1){echo "contact-opener-2";}else if($data->position3 == 2){echo "contact-opener-3";}else{echo "contact-opener";} ?>"><?=$data->name3?></div>
    <div id="contact_results"></div>
    <div id="contact_body">
        <a href="javascript:;" class="close-btn closee-btn"><i class="fa fa-times-circle-o"></i></a>
        <?php echo form_open_multipart('auth/submitContactForm', ['id' => 'the-contact-form', 'class' => 'form']); ?>
        <input type="hidden" name="success_message" value="<?=strip_tags($data->success_message3)?>">
        <div class="row">
            <div class="col-xs-3 form-group" style="padding:0 10px">
                <select class="form-control" name="civility" required>
                    <?php foreach(config_model::$civility as $key => $civil):?>
                        <option value="<?=$civil?>"><?=$civil?></option>
                    <?php endforeach;?>
                </select>
            </div>
            <div class=" form-group col-xs-4">
                <input type="text" maxlength="100" class="form-control" required name="name" placeholder="Nom*">
            </div>

            <div class="form-group col-xs-4">
                <input type="text" maxlength="100" class="form-control" required name="prename" placeholder="Prenom*">
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <div class=" form-group">
                    <input id="enterprise2" maxlength="50" type="text" class="form-control" name="company" placeholder="Entreprise ou Organisme  (Optionnel)">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <div class=" form-group">
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-phone"></i></span>
                        <input id="tel" maxlength="50" type="text" class="form-control" required name="tel" placeholder="Telephone*">
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <div class=" form-group">
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                        <input id="email" maxlength="100" type="email" class="form-control" required name="email" placeholder="Votre email*">
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <div class=" form-group">
                    <textarea rows="3" style="height: 160px" maxlength="3000" class="form-control" name="message" required placeholder="Merci de nous indiquez toutes les informations nécessaires afin de vous fournir un devis pour la prestation de transport souhaitée*"></textarea>
                </div>
            </div>
        </div>
        <!--<div class="row">
            <div class="col-xs-12">
                <div class="form-group">
                    <input type="text" class="bdatepicker" name="dob" placeholder="Date de naissance">
                </div>
            </div>
        </div>-->
        <div class="row">
            <div class="col-xs-12" style="text-align: center">
                <button class="btn-successs" type="submit">ENVOYER</button>
            </div>
        </div>
        <?=form_close();?>
    </div>
</div>
<?php } ?>

<?php if($data->status4 == 1){ ?>
<!-- Jobs Slide Form -->
<div class="<?php if($data->position4 == 1){echo "floating-form-2 ";}else{echo "floating-form ";} ?> <?=$data->auto_open4 == 1 ? "visiable" : ""?>"  id="<?php if($data->position4 == 1){echo "contact_form_2";}else if($data->position4 == 2){echo "jobs_form";}else{echo "support_form";} ?>">
    <div class="<?php if($data->position4 == 1){echo "contact-opener-2";}else if($data->position4 == 2){echo "contact-opener-3";}else{echo "contact-opener-4";} ?>"><?=$data->name4?></div>
    <div id="contact_results"></div>
    <div id="contact_body">
        <a href="javascript:;" class="close-btn-4"><i class="fa fa-times-circle-o"></i></a>
        <?php echo form_open_multipart('auth/submitContactFormPopup', ['id' => 'the-support-form', 'class' => 'form']); ?>
        <input type="hidden" name="success_message" value="<?=strip_tags($data->success_message4)?>">
        <div class="row">
            <div class="col-xs-3 form-group" style="padding:0 10px">
                <select class="form-control" name="civility" required>
                    <?php foreach(config_model::$civility as $key => $civil):?>
                        <option value="<?=$civil?>"><?=$civil?></option>
                    <?php endforeach;?>
                </select>
            </div>
            <div class=" form-group col-xs-4">
                <input type="text" maxlength="100" class="form-control" required name="first_name" placeholder="Nom*">
            </div>

            <div class="form-group col-xs-4">
                <input type="text" maxlength="100" class="form-control" required name="last_name" placeholder="Prenom*">
            </div>
        </div>
        
        <div class="row">
            <div class="col-xs-12">
                <div class=" form-group">
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-phone"></i></span>
                        <input id="tel" maxlength="50" type="text" class="form-control" required name="telephone" placeholder="Telephone*">
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <div class=" form-group">
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                        <input id="email" maxlength="100" type="email" class="form-control" required name="email" placeholder="Email*">
                    </div>
                </div>
            </div>
        </div>
		<div class="row">
            <div class="col-xs-6">
				<div class="form-group">
					<input type="text" name="company_name" class="user-name form-control" placeholder="Entreprise" value="">
				</div>
			</div>
			<div class="col-xs-6">   
					<input type="text" class="phone1 form-control" name="mobile" maxlength="11" placeholder="Mobile" value="">
				</div>
			</div>
        </div>
		<div class="row">
			<div class="col-xs-6">
				<div class="form-group">
					 <select class="form-control" name="department">
						<option value="">-- Department* --</option>
						<option value="10">Booking service</option>
						<option value="11">Clients Service</option>
						<option value="12">Driver Service</option>
						<option value="13">Accounting Service</option>
						<option value="14">Sales Department</option>
						<option value="15">Technical Service</option>
						<option value="16">Disclaimer Service</option>
					</select>
				</div>
			</div>
			<div class="col-xs-6">
				<div class="form-group">
					<select class="form-control" name="priority">
						<option value="">-- Priorité* --</option>
						<option value="High">High</option>
						<option value="Medium">Medium</option>
						<option value="Low">Low</option>
					</select>
				</div>
			</div>
		</div>

        <div class="row">
			<div class="col-md-12">    
				<div class="form-group">
					<input type="text" name="subject" class="user-name form-control" placeholder="Matière" value="" required>
				</div>
			</div>
			<div class="col-md-12">    
				<div class="form-group">
					<textarea class="message form-control" name="visit_message" placeholder="Votre message" rows="25" required></textarea>
				</div>
			</div>
        </div>
        <div class="row">
            <div class="col-xs-12">
				<div class="form-group">
					<label> Télécharger </label>
					<input class="form-control" type="file" name="attachments[]" multiple placeholder="Télécharger" />
				</div>
			</div>
        </div>
        <div class="row">
            <div class="col-xs-12" style="text-align: center">
                <button class="btn-successs" type="submit"><?php echo $this->lang->line('contact_us_button');?></button>
            </div>
        </div>
        <?=form_close();?>
    </div>
<?php } ?>
<style type="text/css">
.contact-opener-5
{
    position: absolute;
    top: -50px;
    left: 0;
    padding: 10px 0 13px;
    color: #fff;
    text-shadow: 1px 1px 1px rgba(0, 0, 0, 0.43);
    cursor: pointer;
    border-radius: 5px 5px 0 0;
    background-color: #5cb85c;
    font-size: 16px;
    font-weight: bold;
    width: 300px;
    text-align: center;
    background-image: linear-gradient(to bottom,#a40185 0%, #7b2e67 39%, #a40185 100%);
    border: 1px solid #a40185;
}
.users-chat-div2{
    clear: both;
    padding-bottom: 8px;
    position: relative;
    background-color: #fff;
    border: 1px solid lightgrey;
    margin-bottom: 5px;
    border-radius: 5px;
}
.user-image-div{
    float: left;
}
.usercontent-div{
    padding-left: 10px;
}
.usercontent-div p{
    margin: 0px;
}
.usercontent-div small{
    color: lightgrey;
}
.real-chat-badge{
    position: absolute;
    top: 0px;
    right: 10px;
    color: grey;
}
.historychating{
    height: 200px;
    overflow: auto;
    margin-bottom: 10px;
}
.historychating::-webkit-scrollbar{
    background-color: lightgrey;
    width: 5px;
}
.historychating::-webkit-scrollbar-thumb{
    background-color: darkgrey;
    width: 5px;
}
</style>
<!-- <div class="<?php if($data->position5 == 5){echo "floating-form-2 ";}else{echo "floating-form ";} ?> <?=$data->auto_open5 == 1 ? "visiable" : ""?>"  id="<?php if($data->position5 == 5){echo "chatform";}else if($data->position5 == 2){echo "jobs_form";}else{echo "support_form";} ?>">
    <div class="<?php if($data->position5 == 5){echo "contact-opener-5";}else if($data->position4 == 2){echo "contact-opener-3";}else{echo "contact-opener-4";} ?>"><i class="fa fa-envelope-o"></i> <?=$data->name5?></div>
        <div class="basic-chat-detail">
        <div class="row">
            <div class="col-md-12">    
                <div class="form-group">
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-user"></i></span>
                        <input id="name" maxlength="100" type="text" class="form-control" required="required" name="name" placeholder="Name*">
                    </div>
                </div>
                <div class="form-group">
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                        <input id="email2" maxlength="100" type="email" class="form-control" required="" name="email" placeholder="Email*">
                    </div>
                </div>
                <div class="form-group">
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-phone"></i></span>
                        <input id="telephone" maxlength="50" type="text" class="form-control" required="required" name="telephone" placeholder="Telephone*">
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12" style="text-align: center">
                <button class="btn-successs" type="button" onclick="validateinputdata()"><?php echo 'Continue';?></button>
            </div>
        </div>
        </div>
        <div class="start-chat-div" style="display: none;">
            <div class="historychating">
                <div class="users-chat-div2">
                   <div class="usercontent-div">
                    <p><strong>Haseen awan</strong></p>
                    <p>Hello world i am here catch me.</p>
                    <span class="real-chat-badge"><small>01-02-2020</small> <i class="fa fa-check" aria-hidden="true"> </i><i class="fa fa-check" aria-hidden="true"></i></span>
                   </div>
               </div>

               <div class="users-chat-div2">
                   <div class="usercontent-div">       
                   <p><span><small>01-02-2020</small></span></p>             
                    <p>Hello world i am here catch me.</p>
                     <i class="fa fa-check" aria-hidden="true"> </i><i class="fa fa-check" aria-hidden="true"></i> 
                    <p class="real-chat-badge"  style="color: #000;"><strong>Me</strong></p>
                   </div>
               </div>
               <div class="users-chat-div2">
                   <div class="usercontent-div">       
                   <p><span><small>01-02-2020</small></span></p>             
                    <p>Hello world i am here catch me.</p>
                      <i class="fa fa-check" aria-hidden="true"> </i><i class="fa fa-check" aria-hidden="true"></i>
                    <p class="real-chat-badge"  style="color: #000;"><strong>Me</strong></p>
                   </div>
               </div>
               <div class="users-chat-div2">
                   <div class="usercontent-div">       
                   <p><span><small>01-02-2020</small></span></p>             
                    <p>Hello world i am here catch me.</p>
                      <i class="fa fa-check" aria-hidden="true"> </i><i class="fa fa-check" aria-hidden="true"></i> 
                    <p class="real-chat-badge"  style="color: #000;"><strong>Me</strong></p>
                   </div>
               </div>
            </div>
            <?php echo form_open_multipart('', ['id' => 'the-chat-form', 'class' => 'form']); ?>
            <div class="form-group">
                <textarea class="form-control" rows="2" placeholder="Enter message" style="height: inherit !important;"></textarea>
            </div>
            <div class="row">
                <div class="col-xs-12" style="text-align: center">
                    <button class="btn-successs" type="button" onclick="validateinputdata()"><?php echo 'Send';?></button>
                </div>
            </div>
            <?=form_close();?>
        </div>
    </div> -->

<script src="<?php echo base_url(); ?>/assets/system_design/scripts/modals_script.js" type="text/javascript"></script>
<script type="text/javascript">
    function validateinputdata()
    {
        var name = $('#name').val();
        var email = $('#email2').val();
        var telephone = $('#telephone').val();
        if(name=="" || name==" " || email=="" || email==" " || telephone=="" || telephone==" ")
        {
            $('#name').css('border','2px solid red');
            $('#email2').css('border','2px solid red');
            $('#telephone').css('border','2px solid red');
        }
        else
        {
            $('.basic-chat-detail').css('display','none');
            $('.start-chat-div').fadeIn('slow');
        }
    }
</script>