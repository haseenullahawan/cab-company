<!--
<?php //if(isset($bread_crumb) && $bread_crumb==true) {?>
<div class="breadcrumb">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
               <aside class="heading"> <?php // if(isset($heading)) echo $heading; ?></aside>
            </div>
            <div class="col-md-6">
               <aside class="nav-links">
                  <ul>
                     <li> <a href="<?php // echo site_url(); ?>/"> <?php // echo $this->lang->line('home');?>  </a> </li>
                     <li><a href="javascript:void(0)"> >> </a></li>
                     <li class="active"><a href="javascript:void(0)">&nbsp;<?php // if(isset($sub_heading)) echo $sub_heading; ?> </a></li>
                  </ul>
               </aside>
            </div>
        </div>
    </div>     
</div>
<?php //} ?>
-->