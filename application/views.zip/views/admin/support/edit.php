<?php $locale_info = localeconv(); ?>
<div class="col-md-12"><!--col-md-10 padding white right-p-->
    <div class="content">
        <?php $this->load->view('admin/common/breadcrumbs');?>
        <div class="row">
            <div class="col-md-12">
                <?php $this->load->view('admin/common/alert');?>
                <div class="module">
                    <?php echo $this->session->flashdata('message'); ?>
                    <div class="module-head">
                    </div>
                    <div class="module-body">
						<?php $attributes = array("enctype" => 'multipart/form-data'); ?>
                        <?=form_open("admin/support/".$data->id."/update", $attributes)?>
                        <div class="row">
                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>Civility*</label>
                                    <select disabled class="form-control" name="civility" required>
                                        <?php foreach(config_model::$civility as $key => $civil):?>
                                            <option <?=set_value('civility',$data->p_title) == $civil ? "selected" : ""?> value="<?=$civil?>"><?=$civil?></option>
                                        <?php endforeach;?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>Nom*</label>
                                    <input disabled type="text" maxlength="100" class="form-control" required name="name" placeholder="Nom*" value="<?=set_value('name',$data->fname)?>">
                                </div>
                            </div>
                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>Prenom*</label>
                                    <input disabled type="text" maxlength="100" class="form-control" required name="prename" placeholder="Prenom*" value="<?=set_value('prename',$data->lname)?>">
                                </div>
                            </div>
                        </div>
						<div class="row">
                            <div class="col-xs-8">
                                <div class="form-group">
                                    <label>Entreprise ou Organisme</label>
									<input disabled type="text" name="company_name" class="form-control" placeholder="Entreprise" value="<?=set_value('company_name',$data->company)?>">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>Email*</label>
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                                        <input disabled id="phone-email" maxlength="100" type="email" class="form-control" required name="email" placeholder="Votre email" value="<?=set_value('email',$data->email)?>">
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>Telephone*</label>
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-phone"></i></span>
                                        <input disabled id="num2" maxlength="50" type="text" class="form-control" required name="tel" placeholder="Telephone" value="<?=set_value('tel',$data->phone)?>">
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>Status*</label>
                                    <select class="form-control" name="status" required>
                                        <?php foreach(config_model::$status as $key => $status):?>
                                            <option <?=set_value('status',$data->status) == $status ? "selected" : ""?> value="<?=$status?>"><?=$status?></option>
                                        <?php endforeach;?>
                                    </select>
                                </div>
                            </div>
                        </div>
						<div class="row">
							
							<div class="col-md-4">   
								<div class="form-group"><label>Mobile</label>
									<input disabled type="text" class="form-control" name="mobile" maxlength="11" placeholder="Mobile" value="<?=set_value('mobile',$data->mobile)?>">
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label>Department <span class="mandatory">*</span></label>  
									 <select disabled class="form-control" name="department">
										<option value="10" <?php echo $data->department==10?'selected':''; ?>>Booking service</option>
										<option value="11" <?php echo $data->department==11?'selected':''; ?>>Clients Service</option>
										<option value="12" <?php echo $data->department==12?'selected':''; ?>>Driver Service</option>
										<option value="13" <?php echo $data->department==13?'selected':''; ?>>Accounting Service</option>
										<option value="14" <?php echo $data->department==14?'selected':''; ?>>Sales Department</option>
										<option value="15" <?php echo $data->department==15?'selected':''; ?>>Technical Service</option>
										<option value="16" <?php echo $data->department==16?'selected':''; ?>>Disclaimer Service</option>
									</select>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label>Priorité  <span class="mandatory">*</span></label>
									<select disabled class="form-control" name="priority">
										<option value="High" <?php echo $data->priority=='High'?'selected':''; ?>>High</option>
										<option value="Medium" <?php echo $data->priority=='Medium'?'selected':''; ?>>Medium</option>
										<option value="Low" <?php echo $data->priority=='Low'?'selected':''; ?>>Low</option>
									</select>
								</div>
							</div>
						</div>
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="form-group">
                                    <label>Subject*</label>
                                    <select disabled class="form-control" name="msg_subject" required>
                                        <?php foreach(config_model::$subjects as $key => $subject):?>
                                            <?php $selected = $key == 1 ? "selected" : ""?>
                                            <option <?=$selected?> value="<?=$subject?>"><?=$subject?></option>
                                        <?php endforeach;?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="form-group">
                                    <label>Message*</label>
                                    <pre class="disabled" style="background: #eee"><?=set_value('message',$data->message)?></pre>
                                </div>
                            </div>
                        </div>
						<div class="row">
                            <div class="col-md-6">
								<div class="form-group">
									<label> Télécharger </label><br/>
									<?php $attachments = $obj->GetSupportAttachments($data->id); ?>
									<?php if(!empty($attachments)){ ?>
									<?php foreach($attachments as $k=>$v){ ?>
									<a target="_blank" href="<?php echo 'http://handi-express.fr/uploads/contact_files/'.$v->filename; ?>"><?php echo $v->filename; ?></a><br/>
									<?php } ?>
									<?php } ?>
								</div>
								<div class="clearfix"></div>
							</div>
                        </div>
                        <div class="text-right">
                            <button type="button" class="btn btn-default replyBtn">Reply</button>
                            <button class="btn btn-default">Update</button>
                            <a href="<?=base_url("admin/support")?>" class="btn btn-default">Cancel</a>
                        </div>
                        <?php echo form_close(); ?>
                        <br>
                        <?=form_open("admin/support/".$data->id . "/reply")?>
                        <div class="row replyDiv">
                            <div class="col-xs-12">
                                <div class="form-group">
                                    <label>Message*</label>
                                    <textarea rows="5" maxlength="5000" class="form-control" id="reply_message" name="reply_message" required placeholder="Write your message"><?=set_value('reply_message')?></textarea>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="row">
                                    <div class="col-md-1" style="padding-top: 5px;white-space: nowrap">
                                        Quick reply:
                                    </div>
                                    <div class="col-md-5">
                                        <div class="form-group">
                                            <select id="quick_replies" class="form-control" name="quick_replies" style="margin-top:2px;">
                                                <option value="">---Select---</option>
                                                <?php foreach ($quick_replies as $q) { ?>
                                                    <option value="<?=$q->id?>"><?=$q->name?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-1" style="padding-top: 5px">
                                        Add files:
                                    </div>
                                    <div class="col-md-3" id="attachDiv">
                                        <div class="row">
                                            <div class="col-xs-8" style="overflow: hidden">
                                                <input type="file" name="attachment[]">
                                            </div>
                                            <div class="col-xs-4">
                                                <button type="button" class="btn btn-circle btn-success btn-sm addFile"><i class="fa fa-plus"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="text-right">
                                            <button class="btn btn-default">Send</button>
                                            <button type="button" class="btn btn-default replyBtn">Cancel</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br>
                        <?php echo form_close(); ?>
                    </div>
                </div>
            </div>
        </div>
        <!--/.module-->
    </div>
    <!--/.content-->
</div>
<div style="display:none;">
<?php foreach ($quick_replies as $q) { ?>
	<span id="message-<?=$q->id?>"><?=$q->message_sentence?></span>
<?php } ?>
</div>
<input type="hidden" id = "replyType" value="4">
<script type="text/javascript">
    $(document).ready(function(){
        $("select[id='quick_replies']").change(function(){
            var val = $(this).val();
			if(val != ''){
				// $.ajax({
					// type: "POST",
					// url: "https://handi-express.fr/support/getQuickReply/"+ val,
					// data: { id: val },
					// success: function(res){
						// alert(res);
						// $("#reply_message").text("");
						// $("#reply_message").text(res);
						// $("#reply_message").attr('readonly',true);
					// }
				// });
				var msg = $('#message-'+val).text();
				$("#reply_message").text(msg);
				$("#reply_message").attr('readonly',true);
				
			}else{
				$("#reply_message").text("");
				$("#reply_message").attr('readonly',false);
			}
        });
    });
</script>