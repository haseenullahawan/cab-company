<?php $locale_info = localeconv(); ?>

    <script src="<?php echo base_url(); ?>/assets/system_design/scripts/bootstrap-datepicker.min.js" type="text/javascript"></script>



<div class="col-md-12"><!--col-md-10 padding white right-p-->

    <div class="content">

        <?php $this->load->view('admin/common/breadcrumbs');?>

        <div class="row">

            <div class="col-md-12">

                <?php $this->load->view('admin/common/alert');?>

                <div class="module">

                    <?php echo $this->session->flashdata('message'); ?>

                    <div class="module-head">

                    </div>

                    <div class="module-body">
                    <?php $attributes = array("enctype" => 'multipart/form-data'); ?>
                    <?php if($data->request_type == 1){ ?>
                        <div id="absence_request" class="drivers_request_div">

                        <?=form_open("admin/drivers_request/".$data->id."/absence_vacation_update", $attributes)?>
                            <div class="row">

                            <div class="col-xs-3">

                                <div class="form-group">

                                    <label>Status*</label>

                                    <select class="form-control" name="status" required>
                                        <option value="">--- Select status ---</option>
                                        <option value="1" <?php if($data->status == 1){ echo "selected"; } ?> >New</option>
                                        <option value="2" <?php if($data->status == 2){ echo "selected"; } ?> >Pending</option>
                                        <option value="3" <?php if($data->status == 3){ echo "selected"; } ?> >approved</option>
                                        <option value="4" <?php if($data->status == 4){ echo "selected"; } ?> >Denied</option>
                                        <option value="5" <?php if($data->status == 5){ echo "selected"; } ?> >Closed</option>
                                    </select>

                                </div>

                            </div>
                            
                            <div class="col-xs-3">

                                <div class="form-group">

                                    <label>Absence Request</label>

                                    <input type="text" class="form-control" name="request" disabled required value="Absence">

                                </div>

                            </div>

                            <div class="col-xs-3">

                                <div class="form-group">

                                    <label>From</label>

                                    <input type="date" class="form-control" name="from_date" disabled value="<?=set_value('from_date',$data->from_date)?>">
                                    
                                    <input type="text" class="form-control" name="from_morning" disabled value="<?=set_value('from_morning',$data->from_morning)?>">
                                </div>

                            </div>

                            <div class="col-xs-3">

                                <div class="form-group">

                                    <label>To</label>

                                    <input type="date" class="form-control" name="to_date" disabled value="<?=set_value('to_date',$data->to_date)?>">

                                    <input type="text" class="form-control" name="to_morning" disabled value="<?=set_value('to_morning',$data->to_morning)?>">
                                </div>

                            </div>
                        </div>

                        <div class="row">

                            <div class="col-xs-6">

                                <div class="form-group">

                                    <label>Description</label>

                                    <textarea class="form-control" name="comment" rows="6" disabled><?=set_value('comment',$data->comment)?></textarea>

                                </div>

                            </div>

                            <div class="clearfix"></div>

                            <div class="col-md-12">
								<div class="form-group">
									<label> Files </label><br/>
									<?php $attachments = $this->GetDriversAttachments($data->id); ?>
									<?php if(!empty($attachments)){ ?>
									<?php foreach($attachments as $k=>$v){ ?>
									<a target="_blank" href="<?php echo 'http://handi-express.fr/uploads/drivers_request/'.$v->filename; ?>"><?php echo $v->filename; ?></a><br/>
									<?php } ?>
									<?php } ?>
								</div>
								<div class="clearfix"></div>
							</div>

                            <div class="clearfix"></div>

                            <div class="col-xs-4">

                                <div class="form-group">

                                    <label>Add proof document files (optional)</label>

                                    <input type="file" class="form-control" name="attachments[]" multiple >

                                </div>

                            </div> 

                                <div class="clearfix"></div>

                                <div class="text-right">

                                    <button class="btn btn-default">Save</button>

                                    <a href="<?=base_url("admin/drivers_request")?>" class="btn btn-default">Cancel</a>

                                </div>                             

                        </div>
                        <!-- </form> -->
                        <?php echo form_close(); ?>
                        </div> 

                        <?php } if($data->request_type == 2){ ?>
                        <div id="vacation_request" class="drivers_request_div">
                        <?=form_open("admin/drivers_request/".$data->id."/absence_vacation_update", $attributes)?>
                            <div class="row">

                                <div class="col-xs-6">

                                    <div class="form-group">

                                        <label>Status*</label>

                                        <select class="form-control" name="status" required>
                                            <option value="">--- Select status ---</option>
                                            <option value="1" <?php if($data->status == 1){ echo "selected"; } ?> >New</option>
                                            <option value="2" <?php if($data->status == 2){ echo "selected"; } ?> >Pending</option>
                                            <option value="3" <?php if($data->status == 3){ echo "selected"; } ?> >approved</option>
                                            <option value="4" <?php if($data->status == 4){ echo "selected"; } ?> >Denied</option>
                                            <option value="5" <?php if($data->status == 5){ echo "selected"; } ?> >Closed</option>
                                        </select>

                                    </div>

                                </div>
                                
                                <div class="col-xs-6">

                                    <div class="form-group">

                                        <label>Medical Vacation Request*</label>

                                        <input type="text" class="form-control" name="request" disabled required value="Medical Absence">

                                    </div>

                                </div>
                            </div>

                            <div class="row">
                                <div class="col-xs-6">

                                    <div class="form-group">

                                        <label>From*</label>

                                        <input type="date" class="form-control" name="from_date" disabled value="<?=set_value('from_date',$data->from_date)?>">

                                        <input type="text" class="form-control" name="from_morning" disabled value="<?=set_value('from_morning',$data->from_morning)?>">
                                    </div>

                                </div>

                                <div class="col-xs-6">

                                    <div class="form-group">

                                        <label>To*</label>

                                        <input type="date" class="form-control" name="to_date" disabled value="<?=set_value('to_date',$data->to_date)?>">

                                        <input type="text" class="form-control" name="to_morning" disabled value="<?=set_value('to_morning',$data->to_morning)?>">
                                    </div>

                                </div>

                                <div class="col-xs-6">

                                    <div class="form-group">

                                        <label>Description*</label>

                                        <textarea class="form-control" name="comment" rows="4" disabled ><?=set_value('comment',$data->comment)?></textarea>

                                    </div>

                                </div>
                                <div class="clearfix"></div>
                                <div class="col-xs-4">

                                    <div class="form-group">
                                        <label>Add Medical proof document files</label>
                                        <input type="file" class="form-control" name="attachments[]" multiple >
                                    </div>

                                </div>  
                                
                                <div class="clearfix"></div>

                                <div class="text-right">

                                    <button class="btn btn-default">Save</button>

                                    <a href="<?=base_url("admin/drivers_request")?>" class="btn btn-default">Cancel</a>

                                </div>
                            </div>
                        <?php echo form_close(); ?>
                        </div>
                        <?php } if($data->request_type == 3){ ?>
                        <div id="salary_advance_request" class="drivers_request_div">
                        <?=form_open("admin/drivers_request/".$data->id."/salary_notes_update", $attributes)?>
                        <div class="row">
                                <div class="col-xs-6">

                                    <div class="form-group">

                                        <label>Status*</label>

                                        <select class="form-control" name="status" required>
                                            <option value="">--- Select status ---</option>
                                            <option value="1" <?php if($data->status == 1){ echo "selected"; } ?> >New</option>
                                            <option value="2" <?php if($data->status == 2){ echo "selected"; } ?> >Pending</option>
                                            <option value="3" <?php if($data->status == 3){ echo "selected"; } ?> >approved</option>
                                            <option value="4" <?php if($data->status == 4){ echo "selected"; } ?> >Denied</option>
                                            <option value="5" <?php if($data->status == 5){ echo "selected"; } ?> >Closed</option>
                                        </select>

                                    </div>
                                </div>

                                <div class="col-xs-6">

                                    <div class="form-group">

                                        <label>Salary Advance Request</label>

                                        <input type="text" class="form-control" disabled value="Salary Advance">

                                    </div>

                                </div>
                                <div class="clearfix"></div> 
                                <div class="col-xs-3">

                                    <div class="form-group">

                                        <label>Amount*</label>

                                        <input type="number" class="form-control" name="amount" id="amount" value="<?=set_value('amount',$data->amount)?>" required>

                                    </div>

                                </div>

                                <div class="col-xs-3">

                                    <div class="form-group">

                                        <label>Time to deduce*</label>

                                        <input type="number" class="form-control" disabled id="time_deduce" disabled value="<?=set_value('time_deduce',$data->time_deduce)?>" >

                                    </div>

                                </div>

                                <div class="col-xs-3">

                                    <div class="form-group">

                                        <label>From Next Month</label>

                                        <input type="text" class="form-control" name="from_month" disabled value="<?=set_value('from_month',$data->from_month)?>" >

                                    </div>

                                </div>

                                <div class="col-xs-3">

                                    <div class="form-group">

                                        <label>To Next Month</label>

                                        <input type="text" class="form-control" name="to_month" id="to_month" disabled value="<?=set_value('to_month',$data->to_month)?>" >

                                    </div>

                                </div>                                    
                                <div class="clearfix"></div> 

                                <div class="col-xs-3">

                                    <div class="form-group">

                                        <label>Paid Amount</label>

                                        <input type="text" class="form-control" id="paid_amount" value="<?=set_value('paid_amount',$data->paid_amount)?>" name="paid_amount" disabled >
                                        <input type="hidden" value="<?php echo $data->paid_amount; ?>" name="get_paid_amount" >
                                    </div>

                                </div> 


                                <div class="col-xs-3">

                                    <div class="form-group">

                                        <label>Rest Due</label>

                                        <input type="text" class="form-control" readonly value="<?=set_value('rest_due',$data->rest_due)?>" id="due" name="rest_due">

                                    </div>

                                </div>

                                <div class="col-xs-3">

                                    <div class="form-group">

                                    <label>Payment Method</label>

                                    <input type="text" class="form-control" name="payment_method" disabled value="<?=set_value('payment_method',$data->payment_method)?>">

                                    </div>
                                </div>

                                <div class="col-xs-3">

                                    <div class="form-group">

                                        <label>Date</label>

                                        <input type="date" class="form-control" name="date" disabled value="<?=set_value('date',$data->date)?>">

                                    </div>

                                </div>

                                <div class="col-xs-12">

                                    <div class="form-group">

                                    <label>Description (optional)</label>

                                    <textarea class="form-control" name="comment" disabled><?=set_value('comment',$data->comment)?></textarea>

                                </div>

                                </div>

                                <div class="col-xs-4">

                                <div class="form-group">

                                    <label>Add proof document files (optional)</label>

                                    <input type="file" class="form-control" name="attachments[]" multiple >

                                </div>

                                </div>  

                                <div class="clearfix"></div>

                                <div class="text-right">

                                    <button class="btn btn-default">Save</button>

                                    <a href="<?=base_url("admin/drivers_request")?>" class="btn btn-default">Cancel</a>

                                </div>

                            </div>
                        </div>
                        <?php echo form_close(); ?>
                        </div>
                        <?php } if($data->request_type == 4){ ?>
                        <div id="notes_refund_request" class="drivers_request_div">
                        <?=form_open("admin/drivers_request/".$data->id."/salary_notes_update", $attributes)?>
                        <div class="row">
                                <div class="col-xs-3">

                                    <div class="form-group">

                                        <label>Status*</label>

                                        <select class="form-control" name="status" required>
                                            <option value="">--- Select status ---</option>
                                            <option value="1" <?php if($data->status == 1){ echo "selected"; } ?> >New</option>
                                            <option value="2" <?php if($data->status == 2){ echo "selected"; } ?> >Pending</option>
                                            <option value="3" <?php if($data->status == 3){ echo "selected"; } ?> >approved</option>
                                            <option value="4" <?php if($data->status == 4){ echo "selected"; } ?> >Denied</option>
                                            <option value="5" <?php if($data->status == 5){ echo "selected"; } ?> >Closed</option>
                                        </select>

                                    </div>
                                </div>

                                <div class="col-xs-3">

                                    <div class="form-group">

                                        <label>Date</label>

                                        <input type="text" class="form-control" name="date" disabled value="<?=set_value('date',$data->date)?>">

                                    </div>

                                </div>                                    

                                <div class="col-xs-3">

                                    <div class="form-group">

                                        <label>Time</label>

                                        <input type="text" class="form-control" name="notes_time" disabled value="<?=date("h:i a", strtotime($data->notes_time))?>" >

                                    </div>

                                </div>

                                <div class="col-xs-3">

                                    <div class="form-group">

                                        <label>Category</label>

                                        <input type="text" class="form-control" name="notes_category" disabled value="<?=set_value('notes_category',$data->notes_category)?>" >

                                    </div>
                                </div>
                                <div class="clearfix"></div>
                                
                                <div class="col-xs-3">

                                    <div class="form-group">

                                        <label>Amount*</label>

                                        <input type="number" class="form-control" id="notes_amount" name="amount" required value="<?=set_value('amount',$data->amount)?>">

                                    </div>

                                </div> 

                                <div class="col-xs-3">

                                    <div class="form-group">

                                        <label>Paid Amount</label>

                                        <input type="number" class="form-control" id="notes_paid_amount" name="notes_paid_amount" disabled value="<?=set_value('notes_paid_amount',$data->paid_amount)?>" >

                                    </div>

                                </div> 


                                <div class="col-xs-3">

                                    <div class="form-group">

                                        <label>Rest Due</label>

                                        <input type="text" class="form-control" id="notes_rest_due" name="notes_rest_due" disabled value="<?=set_value('notes_rest_due',$data->rest_due)?>">

                                    </div>

                                </div>

                                <div class="col-xs-3">

                                    <div class="form-group">

                                        <label>Payment Method</label>

                                        <input type="text" class="form-control" name="payment_method" value="<?=set_value('payment_method',$data->payment_method)?>" disabled>

                                    </div>
                                </div>
                                

                                <div class="clearfix"></div>

                                <div class="col-xs-12">

                                <div class="form-group">

                                    <label>Description*</label>

                                    <textarea class="form-control" name="comment" disabled><?=set_value('comment',$data->comment)?></textarea>

                                </div>

                                </div>

                                <div class="col-xs-4">

                                <div class="form-group">

                                    <label>Add bills proof document files</label>

                                    <input type="file" class="form-control" name="attachments[]" multiple >

                                </div>

                                </div>

                                <div class="clearfix"></div>

                                <div class="text-right">

                                    <button class="btn btn-default">Save</button>

                                    <a href="<?=base_url("admin/drivers_request")?>" class="btn btn-default">Cancel</a>

                                </div>

                            </div>
                        </div>
                        <?php echo form_close(); ?>
                        </div>
                    <?php } ?>

                    </div>

                </div>

            </div>

        </div>

        <!--/.module-->

    </div>

    <!--/.content-->

</div>

<script type="text/javascript">

    $(document).ready(function(){

        $(".bdatepicker").datepicker({

            format: "dd/mm/yyyy"

        });

        $("#notes_amount").on("change", function(){
            let amount = $(this).val();
            let notes_paid_amount = $("#notes_paid_amount").val();

            let due = amount - notes_paid_amount;
            $("#notes_rest_due").val(due.toFixed(2));

        });

        $("#amount").on("change", function(){
            let amount = $(this).val();
            let paid_amount = $("#paid_amount").val();

            let due = amount - paid_amount;
            $("#due").val(due.toFixed(2));

        });

    });

</script>