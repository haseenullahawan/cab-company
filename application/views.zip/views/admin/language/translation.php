<?php 
$locale_info = localeconv(); ?>
<style type="text/css">
    label{font-weight: 600; font-size: 13px;}
    .custom_style_row{margin-top: 30px; margin-bottom: 30px;}
</style>
<script src="./assets/js/inlineEdit.js"></script>
<div class="col-md-12"><!--col-md-10 padding white right-p-->
    <div class="content">
        <?php $this->load->view('admin/common/breadcrumbs');?>
        <div class="row">
            <div class="col-md-12">
                <?php $this->load->view('admin/common/alert');?>
                <div class="module">
                    <?php
                        echo $this->session->flashdata('message');
                        $validation_erros = $this->session->flashdata('validation_errors');
                        if(!empty($validation_erros)){
                    ?>
                        <div class="form-validation-errors alert alert-danger">
                            <h3 style="font-size: 20px; text-align: center;">Validation Errors</h3>
                            <?php echo $validation_erros; ?>
                        </div>
                    <?php } ?>
                    <div class="module-head">
                    </div>
                    <div class="module-body">
                       <!--  <form method="post" action="<?= base_url('language/store_language'); ?>" enctype="multipart/form-data" accept-charset="utf-8" > -->
                       
                          <?=form_open_multipart("language/update_language/".$short_code,'name="trasUser"')?>
                          <table id="example_language" class="cell-border" cellspacing="0" width="100%" data-selected_id="">
                            <thead>
                              <tr>
                                <th class="no-sort text-center"><input type="checkbox" id="chkParent" /></th>
                                <th class="column-id"><?php echo $this->lang->line('id');?></th>
                                <th>English</th>
                                <th><?= ucwords($lang_title); ?></th>
                              </tr>
                            </thead>
                            <tbody>
                              <?
                              foreach ($language as $key => $value) {
                                ?>
                                  <tr>
                                    <td>
                                        <input type="checkbox" value="<?=$value['id'];?>" class="checkbox" name="translation[]">
                                    </td>
                                    <td >

                                        <?=create_timestamp_uid($value['created_at'],$value['id']);?>
                                    </td>
                                    
                                    <td contenteditable="true"
                                        onBlur="change_token(this, 'description','<?= $lang_id; ?>', '<?= $value['token_id']; ?>')"
                                        onClick="showEdit(this);"><?= $value['description']; ?></td>
                                    <td contenteditable="true"
                                        onBlur="saveToDatabase(this, 'translation','<?= $lang_id; ?>', '<?= $value['token_id']; ?>','<?= $value['id']; ?>')"
                                        onClick="showEdit(this);"><?= $value['translation']; ?></td>
                                  </tr>
                                <?
                              }
                              ?>
                              
                            </tbody>
                          </table>
                        <?php echo form_close(); ?>
                    </div>
                </div>
            </div>
        </div>
        <!--/.module-->
    </div>
    <!--/.content-->
</div><?php $locale_info = localeconv(); ?>
<style>
    @media only screen and (min-width: 1400px){
        .table-filter input, .table-filter select{
            max-width: 9% !important;
        }
        .table-filter select{
            max-width: 95px !important;
        }
        .table-filter .dpo {
            max-width: 90px !important;
        }
    }
</style>

<script type="text/javascript">
    function showEdit(editableObj) {
        $(editableObj).css("background", "#FFF");
    }

    function saveToDatabase(editableObj, column, lang_id, token_id, id) {
        $(editableObj)
                .css("background", "#FFF url(./images/loaderIcon.gif) no-repeat center right 5px");
        $.ajax({
            url : '<?= base_url("language/update_translation"); ?>',
            type : "GET",
            data : 'column=' + column + '&data=' + editableObj.innerHTML
                    + '&id=' + id+ '&lang_id=' + lang_id+ '&token_id=' + token_id,
            success : function(data) {
                $(editableObj).css("background", "#FDFDFD");
            }
        });
    }
    function change_token(editableObj, column, lang_id, token_id) {
        $(editableObj)
                .css("background", "#FFF url(./images/loaderIcon.gif) no-repeat center right 5px");
        $.ajax({
            url : '<?= base_url("language/update_token"); ?>',
            type : "GET",
            data : 'column=' + column + '&data=' + editableObj.innerHTML
                    + '&lang_id=' + lang_id+ '&token_id=' + token_id,
            success : function(data) {
                $(editableObj).css("background", "#FDFDFD");
            }
        });
    }
    $(document).ready(function() {
        $('#chkParent').click(function() {
            var isChecked = $(this).prop("checked");
            $('#example_language tr:has(td)').find('input[type="checkbox"]').prop('checked', isChecked);
        });

        $('#example_language tr:has(td)').find('input[type="checkbox"]').click(function() {
            var isChecked = $(this).prop("checked");
            var isHeaderChecked = $("#chkParent").prop("checked");
            if (isChecked == false && isHeaderChecked){
                $("#chkParent").prop('checked', isChecked);
            }
            else {
                $('#example_language tr:has(td)').find('input[type="checkbox"]').each(function() {
                    if ($(this).prop("checked") == false)
                        isChecked = false;
                });
                $("#chkParent").prop('checked', isChecked);
            }
        });
    });
</script>