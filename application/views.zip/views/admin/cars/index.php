<?php $locale_info = localeconv(); ?>

<style>

    .table-filter .dpo {

        max-width: 62px;

    }

    input[type="file"]{
            border: 1px solid #ccc;
    width: 100%;
    width: 200px;
    padding: 3px 0px 3px 5px;
    /* background: #fff; */
    background: #fffdfd;

    }

    input[type="file"]:hover{
            box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.2), 0 0 3px rgba(0, 0, 0, 0.2);

    }

    .table-filter span {

        margin: 4px 2px 0 3px;

    }

    .table-filter input[type="number"]{

        max-width: 48px;

    }

    @media only screen and (min-width: 1400px){

        .table-filter input, .table-filter select{

            max-width: 6% !important;

        }

        .table-filter select{

            max-width: 85px !important;

        }

        .table-filter .dpo {

            max-width: 90px !important;

        }

    }

    

    .nav-tabs > li.active {

        background: linear-gradient(#ffffff, #ffffff 25%, #d0d0d0) !important;
    border-bottom: none;


    }

    

    .nav-tabs > li {

            background-image: linear-gradient(to bottom, #fff 0, #e0e0e0 100%);
            border-left: 1px solid #ccc !important;
    height: 55px;
    margin: 0px !important;

    }

    .nav-tabs > li > a {

    color: #616161 !important;
    font-size: 12px;
    padding-left: 10px;
    display: block !important;
    width: 100% !important;
    height: 100% !important;
    text-transform: uppercase;
    font-weight: bold;
    transition: 0.2s;
    outline: none;
    border: none;
    border-radius: 0px;
}

    }



    #seracTab {

        background: linear-gradient(to bottom, #ffffff 0%, #f6f6f6 47%, #ddd 100%);

        height: 45px;

        margin: 0px 0px 20px 0px;

        border-radius: 4px;

        border: solid 1px #efefef;

        padding: 4px;

        text-align: center;

    }

    thead{

        background: transparent;

        border-bottom: 1px solid #111111;


        font-family: inherit;

        font-size: 100%;

        font-style: inherit;

        font-weight: inherit;

        line-height: 100%;

        vertical-align: baseline;

    }

    th{

        text-shadow: 0 -1px 0 #ffffff;

    }

    .tab-pane{

        padding: 30px;

    }

    table, .col-md-12{

        padding: 0px;

    }

   /*  table.dataTable, table.dataTable th, table.dataTable td {
   
       -webkit-box-sizing: content-box;
   
       -moz-box-sizing: content-box;
   
       box-sizing: content-box;
   
       padding: 0px;
   
   } */

    .table-bordered > thead > tr > th, .table-bordered > tbody > tr > th, .table-bordered > tfoot > tr > th, .table-bordered > thead > tr > td, .table-bordered > tbody > tr > td, .table-bordered > tfoot > tr > td {
    background: #eee;
    color: #2c2c2c;
    font-size: 100%;
    font: inherit;
    vertical-align: baseline;

    }
    .table tbody tr td{
        background-color: white;
    }

    .table{
        padding: 0px;
         margin: 0 auto;
    clear: both;
    border-collapse: separate;
    border-spacing: 0;
    font-size: 12px !important
    }
    .table thead > tr > th{
        background: linear-gradient(#ffffff, #ffffff 25%, #d0d0d0) !important;
        padding: 15px;
        color: #2c2c2c;
        font-weight: bolder;
        font-size: 13px;
    }
    .table-bordered > thead > tr > th, .table-bordered > thead > tr > td {

        border-bottom-width: 1px;

    }



    td{

        padding: 8px;

        line-height: 1.42857143;

        vertical-align: top;

        background-color: #f1f1f1;

    }

    
    input[type="text"],input[type="date"]{
    float: left;
    width: 100%;
    height: 32px !important;
    padding: 2px !important;
    margin-right: 2px !important;
    font-size: 12px;
    }
    input[type="date"]{
        width: 13%;
    }

    input.btn, .btn,button.btn {

        min-height: 28px;

        border: 1px solid #bbb;

        min-width: 80px;

        background-image: linear-gradient(to bottom, #fff 0, #e0e0e0 100%);
        background-repeat: repeat-x;
    border-color: #dbdbdb;
    text-shadow: 0 1px 0 #fff;
    border-color: #ccc;

    }



  /*   button.btn, .btn{
  
      min-height: 20px;
  
      border: 1px solid #bbb;
  
      min-width: 50px;
  
  } */

     .nav-tabs>li>a:hover{

        color: #333;
    background-color: #d4d4d4;
    border-color: #8c8c8c;
}

button.btn:hover, input.btn:hover{
    background-color: #e0e0e0;
    background-position: 0 -15px;
}
    



</style>

<div class="col-md-12"><!--col-md-10 padding white right-p-->

    <div class="content">

        <?php $this->load->view('admin/common/breadcrumbs');?>

        <br>

        <div class="row">

            <div class="col-md-12" id="MainTab">



                    <div id="status" class="tab-pane fade in active" style="width: 100%;border: 1px solid #ccc;padding-top: 10px">

                    <div class="row" id="seracTab">

                        <div class="col-md-8" style="padding-left: 0px;padding-right: 0px;">

                            <span style="float: left;padding: 3px;padding-top: 6px">Search keyword</span>

                            <input type="text" id="searchStatut" class="form-control" style="width: 20%;float:left; " value="">

                            <select name="status" style="float: left;width:18%;" class="form-control">
                                                        <option value="All status"> All status </option>
                                                        <option value="done">done</option>
                                                        <option value="pending">pending</option>
                                                        <option value="confirmed">confirmed</option>
                                                        <option value="cancelled">cancelled</option>
                             </select>

                            <input class="btn" type="button" id="SearchStatutBtn" value="Search" style="float:left;width: 8%;">

                            <input class="btn"  type="reset" id="resetStaut" value="Reset" style="float:left;width: 8%;">

                        </div>

                        <div class="col-md-4" style="padding-left: 0px;padding-right: 0px;">

                                <button  class="btn" id="MainAdd" ><span class="fa fa-plus" > Add</span></button>&nbsp;

                                <button class="btn" name="submit" id="EditStatut" value="Edit"><span class="fa fa-edit"> Edit</span></button>&nbsp;

                                <button   class="btn" name="submit" value="Delete" id="deleteStatut"><span class="fa fa-close"> Delete</span></button>&nbsp;

                                <button   class="btn" name="submit" value="Delete" id="deleteStatut">View Calander</span></button>&nbsp;

                        </div>

                    </div>

                        <br>

                        <div class="row" style="padding:0px;margin: 0px" id="StatusTable">

                            <div class="col-md-12">

                                <table class="table table-bordered data-table dataTable">

                                    <input type="hidden" class="clicked-btn" value="0">

                                    <thead>

                                    <tr>

                                        <th  ></th>

                                        <th  style="text-align: center"  align="center"> ID# </th>

                                        <th align="center"  style="text-align: center">Registration Number</th>

                                        <th align="center"  style="text-align: center">Registration Date</th>

                                        <th align="center"  style="text-align: center">Entery Date</th>
                                        <th align="center"  style="text-align: center">Mark</th>
                                        <th align="center"  style="text-align: center">Series</th>
                                        <th align="center"  style="text-align: center">Places</th>
                                        <th align="center"  style="text-align: center">Fuel</th>
                                        <th align="center"  style="text-align: center">Image</th>
                                        <th align="center"  style="text-align: center">Age</th>
                                        <th align="center"  style="text-align: center">Status</th>


                                    </tr>

                                    </thead>

                                    <tbody id="tableBody">



                                    </tbody>

                                </table>



                            </div>

                        </div>

                    

                    </div>
            </div>



        </div>

        <div class="row hide"  id="ShowTabs">
            
            <div class="col-md-12">
                  <ul class="nav nav-tabs">

                    <li class="active"><a data-toggle="tab" href="#status">STATUS</a></li>

                   <!-- <li><a data-toggle="tab" href="#civility">CIVILITY</a></li>-->

                    <li><a data-toggle="tab" href="#post">POST</a></li>

                    <li><a data-toggle="tab" href="#pattern">PATTERN</a></li>

                    <li><a data-toggle="tab" href="#age">Car Age</a></li>

                    <li><a data-toggle="tab" href="#series">Series</a></li>

                    <li><a data-toggle="tab" href="#boite">Gear Box</a></li>

                    <li><a data-toggle="tab" href="#fuel">Fuel</a></li>

                    <li><a data-toggle="tab" href="#mail">Mail</a></li>

                    <li><a data-toggle="tab" href="#color">Color</a></li>

                    <li ><a data-toggle="tab" href="#nature">Nature</a></li>

                    <li><a data-toggle="tab" href="#type">TYPE</a></li>

                </ul>
                <br>
            </div>
              <div class="tab-content">

                    <!--status tab starts-->

                    <div id="status" class="tab-pane fade in active" style="width: 100%;border: 1px solid #ccc;padding-top: 10px">

                    <div class="row" id="seracTab">

                        <div class="col-md-9" style="padding-left: 0px;padding-right: 0px;">

                            <span style="float: left;padding: 3px;padding-top: 6px">Search keyword</span>

                            <input type="text" id="searchStatut" class="form-control" style="width: 20%;float:left; " value="">

                            <span style="float: left;padding: 3px;padding-top: 3px">From</span>

                            <input type="date" id="start_statut" class="form-control" style="width: 20%;float:left;height: 36px; " value="">

                            <span style="float: left;padding: 3px;padding-top: 6px">To</span>

                            <input type="date" id="end_statut" class="form-control" style="width: 20%;float:left;height: 36px; " value="">

                            <input class="btn" type="button" id="SearchStatutBtn" value="Search" style="float:left;width: 8%;">

                            <input class="btn"  type="reset" id="resetStaut" value="Reset" style="float:left;width: 8%;">

                        </div>

                        <div class="col-md-3" style="padding-left: 0px;padding-right: 0px;">

                                <button  class="btn" id="AddStatus"><span class="fa fa-plus"> Add</span></button>&nbsp;

                                <button class="btn" name="submit" id="EditStatut" value="Edit"><span class="fa fa-edit"> Edit</span></button>&nbsp;

                                <button   class="btn" name="submit" value="Delete" id="deleteStatut"><span class="fa fa-close"> Delete</span></button>&nbsp;



                        </div>

                    </div>

                        <br>

                        <div class="row" style="padding:0px;margin: 0px" id="StatusTable">

                            <div class="col-md-12">

                                <table class="table table-bordered data-table dataTable">

                                    <input type="hidden" class="clicked-btn" value="0">

                                    <thead>

                                    <tr>

                                        <th width="15%" ></th>

                                        <th  style="text-align: center" width="15%" align="center"> ID </th>

                                        <th align="center" width="35%" style="text-align: center">Statut</th>

                                        <th align="center" width="35%" style="text-align: center">Created Date</th>

                                    </tr>

                                    </thead>

                                    <tbody id="StatutTbody">



                                    </tbody>

                                </table>



                            </div>

                        </div>

                        <div class="row hide" style="width: 100%" id="AddStatusForm">

                            <div class="col-md-4"></div>

                            <div class="col-md-4">

                                <div class="form-group">

                                    <span style="font-weight: bold;">Statut:</span>

                                    <input  class="form-control" type="text" id="realstatut" ><br><br>

                                    <button  class="btn" style="margin-top: 10px" id="SaveStatus"><span class="fa fa-save"></span> Save</button>

                                    <button  class="btn" style="margin-top: 10px" id="UpdateCancelStatus"><span class="fa fa-close"> Cancel</span></button>

                                    <br>

                                    <span class="text-danger text-center" id="StatusError"></span>





                                </div>

                            </div>

                            <div class="col-md-4"></div>

                        </div>

                        <div class="row hide" style="width: 100%" id="UpdateStatusForm">

                            <div class="col-md-4"></div>

                            <div class="col-md-4">

                                <div class="form-group">

                                    <span style="font-weight: bold;">Statut:</span>

                                    <input  class="form-control" type="text" id="update_stat"><br><br>

                                    <button  class="btn" style="margin-top: 10px" id="UpdateStatus"><span class="fa fa-save"></span> Update</button>

                                    <button  class="btn" style="margin-top: 10px" id="CancelStatus"><span class="fa fa-close"> Cancel</span></button>

                                    <br>

                                    <span class="text-danger text-center" id="UpdateStatusError"></span>





                                </div>

                            </div>

                            <div class="col-md-4"></div>

                        </div>

                        <br><br><br>

                    </div>

                    <!--status tab ends-->
        </div>

        <!--/.module-->

    </div>

    <!--/.content-->

</div>

<style>

     label > input {

        visibility: hidden;

    }



     label {

        display: block;

        margin: 0 0 0 -10px;

        padding: 0 0 20px 0;

        height: 20px;

        width: 150px;

    }



   label > img {

        display: inline-block;

        padding: 0px;

        height:10px;

        width:10px;

        background: none;

    }



     label > input:checked +img {

        background: url(http://cdn1.iconfinder.com/data/icons/onebit/PNG/onebit_34.png);

        background-repeat: no-repeat;

        background-position:center center;

        background-size:10px 10px;

    }



 

     .form-control {

         display: block;

         width: 100%;

         height: 34px;

         padding: 6px 12px;

         font-size: 14px;

         line-height: 1.42857143;

         color: #555;

         background-color: #fff;

         background-image: none;

         border: 1px solid #ccc;

         border-radius: 4px;

         -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075);

         box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075);

         -webkit-transition: border-color ease-in-out .15s, -webkit-box-shadow ease-in-out .15s;

         -o-transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;

         transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;

     }

     button:active, .btn:active, .button:active, .dataTables_paginate span.paginate_active {

         background-color: #f1f1f1;

         border-color: #b2b2b2 #c7c7c7 #c7c7c7 #b2b2b2;

         -webkit-box-shadow: inset 0 2px 1px rgba(0, 0, 0, 0.1);

         -moz-box-shadow: inset 0 2px 1px rgba(0, 0, 0, 0.1);

         box-shadow: inset 0 2px 1px rgba(0, 0, 0, 0.1);

     }

    input.date{

        width: 13%;

        float: left;

        height: 34px;

    }

</style>

<script>
    $(document).ready(function(){
        $('#MainAdd').click(function(){

            $('#MainTab').hide();
            $('#ShowTabs').attr('class','row');

        });
    })


    function getCaraddes(){
        $.ajax({
            url:"<?php echo base_url('admin/getCaradded') ?>",
            method:"GET",
            success:function(success){
                $('#tableBody').html(success);
            },error:function(xhr){
                console.log(xhr.responseText);
            }
        });
    }

</script>

