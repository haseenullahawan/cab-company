<div class="wrapper">
    <div class="container-fluid body-bg">
        <div class="container body-border">
            <!--<div class="col-md-2 padding si-wi">
                <div class="sidebar">
                    <div id='cssmenu'>
                        <ul>
                            <li <?php if (isset($active_class)) {
                                    if ($active_class == "dashboard") echo 'class="active"';
                                } ?>><a href="<?php echo site_url(); ?>/admin"><span><?php echo $this->lang->line('dashboard'); ?></span></a></li>
                                                            <li <?php if (isset($active_class)) {
                                    if ($active_class == "add_booking") echo 'class="active"';
                                } ?>><a href="<?php echo site_url(); ?>/settings/bookings/Add"><?php echo $this->lang->line('add_booking'); ?></a></li>
                                                            <li <?php if (isset($active_class)) {
                                    if ($active_class == "today_bookings") echo 'class="active"';
                                } ?>><a href="<?php echo site_url(); ?>/settings/todayBookings"><span><?php echo $this->lang->line('today_bookings'); ?></span></a>
                                                            </li>
                                                            <li <?php if (isset($active_class)) {
                                    if ($active_class == "search_bookings") echo 'class="active"';
                                } ?>><a href="<?php echo site_url(); ?>/settings/searchBookings"><span><?php echo $this->lang->line('search_bookings'); ?></span></a>
                                                            </li>
                                                            <li <?php if (isset($active_class)) {
                                    if ($active_class == "all_bookings") echo 'class="active"';
                                } ?>><a href="<?php echo site_url(); ?>/settings/bookings"><span><?php echo $this->lang->line('all_bookings'); ?></span></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>-->