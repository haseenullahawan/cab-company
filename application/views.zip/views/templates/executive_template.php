<?php $this->load->view('executives/common/header'); ?>
<?php $this->load->view('executives/common/navigation'); ?>
<?php  $this->load->view($content); ?>
<?php $this->load->view('executives/common/footer'); ?>