
<?php $this->load->view('admin/common/header'); ?>
<?php $this->load->view('admin/common/navigation'); ?>
<?php  $this->load->view($content); ?>
<?php $this->load->view('admin/common/footer'); ?>