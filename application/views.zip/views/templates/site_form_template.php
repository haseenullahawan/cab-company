<?php $this->load->view('site/common/form_header'); ?>
<?php  $this->load->view($content); ?>
<?php $this->load->view('site/common/form_footer'); ?>